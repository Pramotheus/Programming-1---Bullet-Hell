#pragma once
#include "Bullet.h"
#include"GameObjectManager.h"
#include"Boss.h"
#include <math.h>
#include"game.h"


//---------------------------------------------------------------------------------------------------------------------
//Function Name: Bullet()
//		 Inputs: N/A
//	    Outputs: Initializes base values when the bullet is instanced in the pool
//	Description: ^
//				
//----------------------------------------------------------------------------------------------------------------------
Bullet::Bullet()
{
	VelocityMagnitude = 100;
	Velocity.x = 0;
	Velocity.y = 0;
	TextureFilePath = "Sprites/LivesA.png";
	Position.x = 0;
	Position.y = 0;
	Height = 96;
	Width = 96;
	Angle = 0;
	AngularVelocity = 5;
	SplitTime = 0;


}




Bullet::~Bullet()
{
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: GetLinearXVelocity
//		 Inputs: N/A
//	    Outputs: Get X component of velocity
//	Description: ^
//				
//----------------------------------------------------------------------------------------------------------------------

float Bullet::GetLinearXVelocity()
{
	return (float)VelocityMagnitude*(float)std::cos(Angle * (3.1415 / 180));
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: GetLinearVelocity()
//		 Inputs: N/A
//	    Outputs: Get Y component of velocity
//	Description: ^
//				
//----------------------------------------------------------------------------------------------------------------------

float Bullet::GetLinearYVelocity()
{
	return (float)VelocityMagnitude*(float)std::sin(Angle * (3.1415 / 180));
}


//---------------------------------------------------------------------------------------------------------------------
//Function Name: Update(DWPRD)
//		 Inputs: Delta Time
//	    Outputs: Updates the position of the bullet according to the pattern it uses
//	Description: Uses a function pointer array to identify the update function it's suppose to use to update it's position
//				
//----------------------------------------------------------------------------------------------------------------------
bool Bullet::Update(DWORD Milliseconds)
{

	(this->*UpdateFunctionPointer[PatternID])(Milliseconds);

	if (Angle > 360)
	{
		Angle = 0;
	}

	if (Position.y > 2000 || Position.y < -2000 || Position.x>2000 || Position.x < -2000)
	{
		return false;
	}

	return true;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Draw()
//		 Inputs: Drawing Initialization must have been done and the texture must've been bound previously
//	    Outputs: Draws the bullet to the screen 
//	Description: 
//				
//----------------------------------------------------------------------------------------------------------------------

void Bullet::Draw()
{
	//Render(GlTextureHandle);

	GLfloat XPositionLeft = Position.x - (Width / 2);
	GLfloat XPositionRight = Position.x + (Width / 2);
	GLfloat YPositionTop = Position.y + (Height / 2);
	GLfloat YPositionBottom = Position.y - (Height / 2);

	/*GLfloat XTextureCoord = 1;
	GLfloat YTextureCoord = 1;*/

	glColor4ub(0xFF, 0xFF, 0xFF, 0xFF);

	//Bottom Left Vertex
	glTexCoord2f(0, 0);
	glVertex3f(XPositionLeft, YPositionBottom, 0);

	//Bottom Right Vertex
	glTexCoord2f(1, 0);
	glVertex3f(XPositionRight, YPositionBottom, 0);

	//Top Right Vertex
	glTexCoord2f(1, 1);
	glVertex3f(XPositionRight, YPositionTop, 0);

	//Top Left Vertex
	glTexCoord2f(0, 1);
	glVertex3f(XPositionLeft, YPositionTop, 0);

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Initialize(float PositionX, float PositionY, float Velocity, int PID, GLuint TextureHandle, float InitialAngle)
//		 Inputs: Variables listed above
//	    Outputs: Initializes a bullet according to the parameters passed in
//	Description: 
//				
//----------------------------------------------------------------------------------------------------------------------
void Bullet::Initialize(float PositionX, float PositionY, float Velocity, int PID, GLuint TextureHandle, float InitialAngle)
{
	PatternID = PID;
	Position.x = PositionX;
	Position.y = PositionY;
	VelocityMagnitude = Velocity;
	GlTextureHandle = TextureHandle;
	Angle = InitialAngle;
	WaveAngle = 0;
	SplitTime = CGame::GetInstance()->GetElapsedTime() + 1;
	SplitTarget = 0;

	if (PID == Patterns::SPLIT_SHOT_LEFT_FULL_RANDOM || PID== Patterns::SPLIT_SHOT_RIGHT_FULL_RANDOM)
	{
		SplitTime = CGame::GetInstance()->GetElapsedTime() + getRangedRandom(1,3);
	}
	
}

//All the functions below update the position of the bullet accordings to a specific pattern as given by their name


void Bullet::LinearPlayerBulletUpdate(DWORD Milliseconds)
{
	Position.y += VelocityMagnitude*(Milliseconds / 10);
}


void Bullet::LinearAngledUpdate(DWORD Milliseconds)
{
	Position.y += GetLinearYVelocity()*(Milliseconds / 10);
	Position.x += GetLinearXVelocity()*(Milliseconds / 10);

}

void Bullet::InverseLinearAngledUpdate(DWORD Milliseconds)
{
	Position.y += GetLinearYVelocity()*(Milliseconds / 10);
	Position.x -= GetLinearXVelocity()*(Milliseconds / 10);
}

void Bullet::WhirpoolBulletUpdate(DWORD Milliseconds)
{

	Position.y += GetLinearYVelocity() *(Milliseconds / 10);
	Position.x += GetLinearXVelocity() *(Milliseconds / 10);
	Angle += AngularVelocity *(Milliseconds / 10);
	Position.y += -4;
	
}

void Bullet::WaveUpdate(DWORD Milliseconds)
{
	Position.y += GetLinearYVelocity() *(Milliseconds / 10);
	Position.x += GetLinearXVelocity() *(Milliseconds / 10);

	Position.x += (float)10*(float)std::cos(WaveAngle * (3.1415 / 180)) *(Milliseconds / 10);
	Position.y += (float)10*(float)std::sin(WaveAngle * (3.1415 / 180)) *(Milliseconds / 10);

	WaveAngle += AngularVelocity*(Milliseconds / 10);; 
	//Angle += AngularVelocity*(Milliseconds / 10);;

	if (WaveAngle > 360)
	{
		WaveAngle = 0;
	}

}

void Bullet::InverseWaveUpdate(DWORD Milliseconds)
{
	Position.y += GetLinearYVelocity() *(Milliseconds / 10);
	Position.x += GetLinearXVelocity() *(Milliseconds / 10);

	Position.x -= (float)10 * (float)std::cos(WaveAngle * (3.1415 / 180)) *(Milliseconds / 10);
	Position.y -= (float)10 * (float)std::sin(WaveAngle * (3.1415 / 180)) *(Milliseconds / 10);

	WaveAngle += AngularVelocity*(Milliseconds / 10);;
	//Angle += AngularVelocity*(Milliseconds / 10);;

	if (WaveAngle > 360)
	{
		WaveAngle = 0;
	}
}

void Bullet::SplitShotLeftFullRandom(DWORD Milliseconds)
{
	//SplitTime++;

	if (SplitTime > CGame::GetInstance()->GetElapsedTime())
	{
		LinearAngledUpdate(Milliseconds);
	}
	else
	{
		GameObjectManager::GetInstance()->AddBullet(Position.x , Position.y, getRangedRandom(10, 25), Patterns::LINEAR_ANGLED, 2, getRangedRandom(270,360));
		GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, getRangedRandom(10, 20), Patterns::LINEAR_ANGLED, 2, getRangedRandom(270, 360));
		//GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 20, Patterns::LINEAR_ANGLED, 1, getRangedRandom(270, 360));

		Position.y = 2050;
	}
}

void Bullet::SplitShotRightFullRandom(DWORD Milliseconds)
{
	//SplitTime++;

	if (SplitTime > CGame::GetInstance()->GetElapsedTime())
	{
		LinearAngledUpdate(Milliseconds);
	}
	else
	{

		GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, getRangedRandom(10, 25), Patterns::LINEAR_ANGLED, 2, getRangedRandom(180, 270));
		GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, getRangedRandom(10, 20), Patterns::LINEAR_ANGLED, 2, getRangedRandom(180, 270));
		//GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 20, Patterns::LINEAR_ANGLED, 1, getRangedRandom(180, 270));

		Position.y = 2050;
	}
}

void Bullet::SplitShotConstant(DWORD Milliseconds)
{
	//SplitTime++;

	if (SplitTime > CGame::GetInstance()->GetElapsedTime())
	{
		LinearAngledUpdate(Milliseconds);
	}
	else
	{
		GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 20, Patterns::LINEAR_ANGLED, 2, getRangedRandom(245, 295));
		GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 20, Patterns::LINEAR_ANGLED, 2, getRangedRandom(245, 295));
		//GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, getRangedRandom(10, 20), Patterns::LINEAR_ANGLED, 1, getRangedRandom(225, 315));
		Position.y = 2050;
	}

}

void Bullet::TargetPlayer(DWORD Milliseconds)
{
	Coord2D playerPosition = GameObjectManager::GetInstance()->ReturnPlayerPosition();
	if(SplitTime > CGame::GetInstance()->GetElapsedTime())
	{
	int temp;
	temp = ((atan2(playerPosition.y - Position.y, playerPosition.x - Position.x) *(180 / 3.141592653589793)));// *(Milliseconds / 10);
	
	if (temp < 0)
	{
		temp = 360 + temp;
	}

	if (Angle < temp)
	{
		Angle += AngularVelocity*(Milliseconds / 10);;
	}
	else
	{
		Angle -= AngularVelocity*(Milliseconds / 10);;
	}
	}
	LinearAngledUpdate(Milliseconds);
}

void Bullet::TargetPlayerSplit(DWORD Milliseconds)
{
	Coord2D playerPosition = GameObjectManager::GetInstance()->ReturnPlayerPosition();

	Angle = ((atan2(playerPosition.y - Position.y, playerPosition.x - Position.x) *(180 / 3.141592653589793)));
	SplitShotConstant(Milliseconds);
}
