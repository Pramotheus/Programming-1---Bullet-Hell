#pragma once
#include "StarField.h"
#include<ctime>



StarField::StarField()
{
}


StarField::~StarField()
{
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: StarField(int,int)
//		 Inputs: X and Y Bounds on the screen (coordinates)
//	    Outputs: Initializes the Starfield
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

StarField::StarField(int BoundX, int BoundY)
{

	StarTexture = SOIL_load_OGL_texture("Sprites/flare.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID,
		SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);

	/*TempTexture = SOIL_load_OGL_texture("Sprites/Galaxy.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID,
		SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);*/

	Bounds.x = BoundX;
	Bounds.y = BoundY;

	XRandom.seed(std::time(0));
	YRandom.seed(std::time(0) + 12);

	XDistribution = std::uniform_int_distribution<int>(-BoundX, BoundX);
	YDistribution = std::uniform_int_distribution<int>(-BoundY, BoundY);

	MaxStars[0] = 100;
	MaxStars[1] = 200;
	MaxStars[2] = 300;

	VelocityFactor = 1;

	Star *temp;

	while (SmallStars.size() < MaxStars[2])
	{
		temp = new Star(XDistribution(XRandom), YDistribution(YRandom), 8, 8);
		SmallStars.push_back(temp);
	}

	while (MediumStars.size() < MaxStars[1])
	{
		temp = new Star(XDistribution(XRandom), YDistribution(YRandom), 16, 16);
		MediumStars.push_back(temp);
	}

	while (LargeStars.size() < MaxStars[0])
	{
		temp = new Star(XDistribution(XRandom), YDistribution(YRandom), 32, 32);
		LargeStars.push_back(temp);
	}

	/*Temporary = new Star(XDistribution(XRandom), YDistribution(YRandom), 512, 512);*/

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Draw()
//		 Inputs: N/A
//	    Outputs: Draws the Starfield to the screen
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void StarField::Draw()
{

	//glEnable(GL_TEXTURE_2D);
	//glBindTexture(GL_TEXTURE_2D, TempTexture);
	//glBegin(GL_QUADS);
	//Temporary->Draw();
	//glEnd();

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, StarTexture);
	glBegin(GL_QUADS);

	for (std::vector<Star*>::iterator it = SmallStars.begin(); it != SmallStars.end(); it++)
	{
		(*it)->Draw();
	}

	for (std::vector<Star*>::iterator it = MediumStars.begin(); it != MediumStars.end(); it++)
	{
		(*it)->Draw();
	}

	for (std::vector<Star*>::iterator it = LargeStars.begin(); it != LargeStars.end(); it++)
	{
		(*it)->Draw();
	}

	glEnd();

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Update()
//		 Inputs: N/A
//	    Outputs: Updates the position of the different stars in the Starfield at different speeds to create a parallax effect
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void StarField::Update()
{

	for (std::vector<Star*>::iterator it = SmallStars.begin(); it != SmallStars.end(); it++)
	{
		(*it)->AddYPosition(-1 * VelocityFactor);
		if ((*it)->GetPosition().y < -Bounds.y)
		{
			(*it)->SetPosition(XDistribution(XRandom), 2000);
		}
	}

	for (std::vector<Star*>::iterator it = MediumStars.begin(); it != MediumStars.end(); it++)
	{
		(*it)->AddYPosition(-2 * VelocityFactor);
		if ((*it)->GetPosition().y < -Bounds.y)
		{
			(*it)->SetPosition(XDistribution(XRandom), 1950);
		}
	}

	for (std::vector<Star*>::iterator it = LargeStars.begin(); it != LargeStars.end(); it++)
	{
		(*it)->AddYPosition(-4 * VelocityFactor);
		if ((*it)->GetPosition().y < -Bounds.y)
		{
			(*it)->SetPosition(XDistribution(XRandom), 1950);
		}
	}

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: ToggleHyperSpace
//		 Inputs: N/A
//	    Outputs: Adjust the velocity factor to make it looks like the starfield is moving faster or slower
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void StarField::ToggleHyperSpace()
{
	if (VelocityFactor > 1)
	{
		VelocityFactor = 1;
	}
	else
	{
		VelocityFactor = 30;
	}

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Shutdown()
//		 Inputs: N/A
//	    Outputs: Delete Starfield
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void StarField::ShutDown()
{
	std::vector<Star*>::iterator it;

	for (it = SmallStars.begin(); it != SmallStars.end(); it++)
	{
		delete (*it);
		it = SmallStars.erase(it);
	}

	for (it = MediumStars.begin(); it != MediumStars.end(); it++)
	{
		delete (*it);
		it = MediumStars.erase(it);
	}

	for (it = LargeStars.begin(); it != LargeStars.end(); it++)
	{
		delete (*it);
		it = LargeStars.erase(it);
	}

}