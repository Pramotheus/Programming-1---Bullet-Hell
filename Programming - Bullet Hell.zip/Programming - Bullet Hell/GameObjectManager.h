#pragma once
#include<iostream>
#include<vector>
#include"glut.h"
#include"gl\gl.h"
#include"GameObject.h"
#include"BulletPool.h"


const int BulletPoolSize = 500;
const int PlayerBulletPoolSize = 25;



class GameObjectManager
{
public:
	GameObjectManager();
	~GameObjectManager();
	static GameObjectManager* CreateInstance();
	static GameObjectManager* GetInstance();
	void AddGameObject(GameObject*);
	void AddBullet(float PositionX, float PositionY, float Velocity, int PID, int BulletTextureIndex, float InitialAngle);
	void AddPlayerBullet(float PositionX, float PositionY, float Velocity, int PID, int BulletTextureIndex, float InitialAngle);
	void EmptyPlayerBullets();
	void SpawnFinalBoss();
	void ResetObjects();
	void RemoveGameObject(GameObject*);
	BulletPool* ReturnBulletPool();

	void DrawOnlyPlayerObject();
	void DrawAllObjects();

	void UpdateAllObjects(DWORD);
	void UpdateOnlyPlayer(DWORD);

	void PerformCollisions();
	void Shutdown();
	Coord2D ReturnPlayerPosition();

private:
	std::vector<GLuint> BossTextures;
	std::vector<GameObject*> GameObjectList;
	BulletPool *BPool;
	BulletPool *PlayerBPool;
	BulletPool *VioletBPool;

	static GameObjectManager* GManagerInstance;
	void Initialize();
	void SpawnNextBoss();

	int PlayerIndex;
	int BossIndex;
	int CurrentBulletTexturesIndex;
	int CurrentBossTextureIndex;

};

