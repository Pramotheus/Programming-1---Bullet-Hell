#pragma once
#include"GameObject.h"
#include"baseTypes.h"
#include"random.h"


class Bullet:public GameObject
{
public:
	Bullet();
	~Bullet();
	void Initialize(float PositionX, float PositionY, float Velocity, int PID, GLuint TextureHandle, float InitialAngle);

private:
	int PatternID;
	float Angle;
	float AngularVelocity;
	float WaveAngle;
	int SplitTime;
	int SplitTarget;

	bool Update(DWORD);
	void Draw();

	float GetLinearXVelocity();
	float GetLinearYVelocity();

	void LinearPlayerBulletUpdate(DWORD);
	void LinearAngledUpdate(DWORD);
	void InverseLinearAngledUpdate(DWORD Milliseconds);
	void WhirpoolBulletUpdate(DWORD);
	void WaveUpdate(DWORD);
	void InverseWaveUpdate(DWORD);
	void SplitShotRightFullRandom(DWORD);
	void SplitShotLeftFullRandom(DWORD);
	void SplitShotConstant(DWORD);
	void TargetPlayer(DWORD);
	void TargetPlayerSplit(DWORD);

	void(Bullet::*UpdateFunctionPointer[11])(DWORD) = {&Bullet::LinearPlayerBulletUpdate,&Bullet::LinearAngledUpdate, &Bullet::InverseLinearAngledUpdate, &Bullet::WhirpoolBulletUpdate, 
													&Bullet::WaveUpdate, &Bullet::InverseWaveUpdate, &Bullet::SplitShotLeftFullRandom, &Bullet::SplitShotRightFullRandom, &Bullet::SplitShotConstant, &Bullet::TargetPlayer, &Bullet::TargetPlayerSplit};
};

