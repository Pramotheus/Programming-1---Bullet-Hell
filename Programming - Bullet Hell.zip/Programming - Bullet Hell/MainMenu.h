#pragma once
#include<vector>
#include<string>

class MainMenu
{
public:
	
	static MainMenu* GetInstance();
	static MainMenu* CreateInstance();
	void Draw();
	void Update();
	MainMenu();
	~MainMenu();

private:
	static MainMenu *Instance;
	std::vector<std::string> MainMenuText;
};

