#pragma once
#include"baseTypes.h"

class Star
{
public:
	Star();
	Star(float, float, int, int);
	~Star();

	void SetPosition(float, float);
	Coord2D GetPosition();
	void AddYPosition(float);
	void Draw();

private:
	Coord2D Position;
	int Width;
	int Height;


};

