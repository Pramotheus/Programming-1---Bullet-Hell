#include "AudioManagerC.h"
#include "Audio.h"

AudioManagerC* AudioManagerC::audioManagerInstance = nullptr;

AudioManagerC* AudioManagerC::CreateInstance()
{
	if (audioManagerInstance == nullptr)
	{
		audioManagerInstance = new AudioManagerC();
	}
	return audioManagerInstance;
}

//initialise the audio files and make it ready to be called for play
void AudioManagerC::Init()
{
	mAudio = new Audio();

	//store the audio ques created in sound vector
	soundVector.push_back(mAudio->createSound("Sounds/creep_shot.wav"));
	soundVector.push_back(mAudio->createSound("Sounds/CollisionSound.wav"));
	soundVector.push_back(mAudio->createSound("Sounds/NieR_A_WretchedWeaponry8bit.mp3"));
	soundVector.push_back(mAudio->createSound("Sounds/DunDunDun.mp3"));

	//play bagroud music on initialization in loop
	PlaySounds(SoundIndex::BackgroundTheme, true);
}

void AudioManagerC::Update()
{

}

//call at the end of the game to release the audio
void AudioManagerC::shutdown()
{
	// Release sounds
	for (int i = 0; i < soundVector.size(); i++)
	{
		mAudio->releaseSound(*soundVector[i]);
	}
	//iterate through sounds and delete them from the channels
	for (std::vector<Sound*>::iterator it = soundVector.begin(); it != soundVector.end();)
	{
		delete (*it);
		it = soundVector.erase(it);
	}

}

//Plays the sound specified based on the index of the SoundIndex Enum
void AudioManagerC::PlaySounds(SoundIndex Value, bool isLoop)
{
	mAudio->playSound(*soundVector[Value], isLoop);
}

