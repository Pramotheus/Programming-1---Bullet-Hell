#pragma once
#include<iostream>
#include<vector>
#include<map>
#include"GameObject.h"
#include"Bullet.h"

class GameObjectManager;

class BulletPool
{
public:
	BulletPool();
	~BulletPool();
	
	void GetBullet(float PositionX, float PositionY, float Velocity, int PID, int BulletTextureIndex, float InitialAngle);
	std::vector<GameObject*>::iterator RemoveBullet(std::vector<GameObject*>::iterator it);
	void Initialize(int Size);
	void ShutDown();

private:
	static std::vector<std::string> TextureFilePaths;
	static std::vector<GLuint> TextureHandles;

	std::vector<GameObject*> InactiveBullets;
	std::vector<GameObject*> ActiveBullets;
	int PoolSize;


	friend class GameObjectManager;
};

