#ifndef AUDIO_H
#define AUDIO_H

#include "fmod.hpp"
#include "fmod_errors.h"

typedef FMOD::Sound* Sound;

class Audio
{
public:
	Audio();

	Sound* createSound(const char* pFile);
	void playSound(Sound &pSound, bool loop);
	void releaseSound(Sound &pSound);

private:
	FMOD::System* mSystem;
};

#endif