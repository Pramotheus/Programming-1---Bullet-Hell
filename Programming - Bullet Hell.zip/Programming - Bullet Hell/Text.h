#pragma once
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include "glut.h"
#include <string>
#include <vector>

#ifndef TEXT_H
#define TEXT_H
#endif

class UI
{
private:
	static UI	*textInstance;
	static int MaxHealth;
	std::vector<std::string> CreditsText;
public:
	UI();

	static UI	*CreateInstance();
	static UI	*GetInstance() { return textInstance; };

	void displayScore(int score);
	void displayBossHeath(int health);
	void displayPlayerHealth(int health, float playerPositionX, float playerPositionY);
	void setMaxHealth(int value);
	void DisplayCredits();
	void DisplayFinaleText();
	void Shutdown();

	~UI();
};

