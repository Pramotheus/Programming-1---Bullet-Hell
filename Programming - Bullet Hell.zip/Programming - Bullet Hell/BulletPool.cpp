#include "BulletPool.h"

std::vector<std::string> BulletPool::TextureFilePaths;
std::vector<GLuint> BulletPool::TextureHandles;

BulletPool::BulletPool()
{
}


BulletPool::~BulletPool()
{
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: GetBullet(float,float,float,int,int,float)
//		 Inputs: Parameters required to spawn the bullet
//	    Outputs: Adjusts the bullet pool accordingly and spawns a bullet
//	Description: ^
//				 
//----------------------------------------------------------------------------------------------------------------------
void BulletPool::GetBullet(float PositionX, float PositionY, float Velocity, int PID, int BulletTextureIndex, float InitialAngle)
{
	if (!InactiveBullets.empty())
	{
		InactiveBullets[0]->Initialize(PositionX, PositionY, Velocity, PID, TextureHandles[BulletTextureIndex], InitialAngle);
		ActiveBullets.push_back(InactiveBullets[0]);
		InactiveBullets.erase(InactiveBullets.begin());
	}
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: RemoveBullet(std::vector<GameObject*>::iterator)
//		 Inputs: An iterator to the active bullets vector
//	    Outputs: Removes the bullet from the active list and puts it in the inactive list
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

std::vector<GameObject*>::iterator BulletPool::RemoveBullet(std::vector<GameObject*>::iterator it)
{
	InactiveBullets.push_back((*it));
	it=ActiveBullets.erase(it);
	return it;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Initialize()
//		 Inputs: Bullet Pool size
//	    Outputs: Initializes the bullet pool with bullets equal to size that was passed, also preloads bullet textures
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void BulletPool::Initialize(int Size)
{
	static bool IsInitialized = false;
	PoolSize = Size;
	GameObject *temp;
	for (int i = 0; i < PoolSize; i++)
	{

		temp = new Bullet();
		InactiveBullets.push_back(temp);
	}
	ActiveBullets.reserve(800);
	InactiveBullets.reserve(800);

	//int a;
	//a = ActiveBullets.size();
	//a = ActiveBullets.capacity();
	//a = InactiveBullets.size();
	//a = InactiveBullets.capacity();
	if (IsInitialized == false)
	{
		TextureFilePaths.push_back("Sprites/LivesA.png");

		TextureFilePaths.push_back("Sprites/LivesB.png");			//Bullet Hell
		TextureFilePaths.push_back("Sprites/LivesC.png");

		TextureFilePaths.push_back("Sprites/Dragonball.png");		//Dragonball
		TextureFilePaths.push_back("Sprites/KiBlast.png");

		TextureFilePaths.push_back("Sprites/Pokeball.png");			//Pokemon-4
		TextureFilePaths.push_back("Sprites/Pikachu.png");

		TextureFilePaths.push_back("Sprites/Kirby.png");			//Smashbros
		TextureFilePaths.push_back("Sprites/Mario.png");

		TextureFilePaths.push_back("Sprites/FroggerCar.png");			   //Frogger
		TextureFilePaths.push_back("Sprites/Frog.png");

		TextureFilePaths.push_back("Sprites/Pacman.png");			//Pacman
		TextureFilePaths.push_back("Sprites/Pacman2.png");

		TextureFilePaths.push_back("Sprites/Squid1.png");			//Splatoon
		TextureFilePaths.push_back("Sprites/Squid2.png");

		TextureFilePaths.push_back("Sprites/Bee.png");				//Arkanoid
		TextureFilePaths.push_back("Sprites/Ball.png");

		TextureFilePaths.push_back("Sprites/C.png");				//Tom
		TextureFilePaths.push_back("Sprites/TomVersion.png");

		TextureFilePaths.push_back("Sprites/C.png");			//Paul
		TextureFilePaths.push_back("Sprites/Plus.png");

		GLuint TempHandle;

		for (std::vector<std::string>::iterator it = TextureFilePaths.begin(); it != TextureFilePaths.end(); it++)
		{

			TempHandle = SOIL_load_OGL_texture((*it).c_str(), SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID,
				SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);
			TextureHandles.push_back(TempHandle);
		}

		IsInitialized = true;
	}

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: ShutDown()
//		 Inputs: N/A
//	    Outputs: Deletes the bulletpool
//	Description: ^
//				 
//----------------------------------------------------------------------------------------------------------------------

void BulletPool::ShutDown()
{
	std::vector<GameObject*>::iterator it;
	for (it = ActiveBullets.begin(); it != ActiveBullets.end();)
	{
		delete (*it);
		it = ActiveBullets.erase(it);
	}

	for (it = InactiveBullets.begin(); it != InactiveBullets.end();)
	{
		delete (*it);
		it = InactiveBullets.erase(it);
	}
}