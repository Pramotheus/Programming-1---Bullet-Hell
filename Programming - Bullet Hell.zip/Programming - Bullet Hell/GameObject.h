#pragma once
#include<Windows.h>
#include"glut.h"
#include"gl\gl.h"
#include"baseTypes.h"
#include<string>
#include"SOIL.h"

class GameObject
{
public:
	GameObject();
	virtual ~GameObject();
	virtual bool Update(DWORD);
	virtual void Draw();
	virtual void Initialize(float PositionX, float PositionY, float Velocity, int PID, GLuint TextureHandle, float InitialAngle);

	void Render(GLuint TextureHandle);
	GLuint GetTextureHandle();
	Coord2D GetPosition();
	float GetWidth();
	float GetHeight();

protected:
	float VelocityMagnitude;
	Coord2D Velocity;
	Coord2D Position;
	float Width;
	float Height;
	GLuint GlTextureHandle;
	std::string TextureFilePath;
	//char TextureFilePath[30];

};

