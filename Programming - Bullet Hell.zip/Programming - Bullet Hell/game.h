#pragma once
#include<iostream>
#include<vector>
#include"StarField.h"

struct BossSpawnData
{
	Coord2D Position;
	float VelocityMagnitude;
	float Width;
	float Height;
	float Health;
	float FireRate;
	int	 BossID;
	Coord2D SpawnOffsets[3];
	std::string TextureFilePath;
};

class CGame
{
public:
	const char8_t *GetGameTitle(){return mGameTitle;}
	static CGame	*CreateInstance();
	static CGame	*GetInstance() {return sInstance;};
	double GetElapsedTime();
	bool EndGameReached();
	~CGame();
	void DrawScene();
	void UpdateFrame(DWORD milliseconds);
	void DestroyGame();
	void init();
	void shutdown();
	void AddScore(int);
	void InitializeBossData();
	void ActivateTransitionMode();
	void InitiateCreditsMode();
	void EndGameScreen();
	void StartGame();
	void RestartGame();
	std::vector <std::string> ReturnTexturePaths();
	BossSpawnData GetBossData();
	static const uint32_t mScreenWidth = 1024;
	static const uint32_t mScreenHeight = 768;
	static const uint32_t mBitsPerPixel = 32;
private:

	static float TransitionEndTime;
	static const char8_t mGameTitle[50];
	static CGame *sInstance;
	static double ElapsedTime;
	static int Score;
	static std::vector<BossSpawnData> SpawnData;
	static int CurrentBossIndex;
	static bool EndGame;
	static int Mode;
	static StarField *SField;
	CGame(){};
};