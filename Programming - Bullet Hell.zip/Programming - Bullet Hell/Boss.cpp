#pragma once
#include "Boss.h"
#include"GameObjectManager.h"
#include"game.h"
#include "Text.h"
#include <math.h>


Boss::Boss()
{
	VelocityMagnitude = 10;
	Velocity.x = 10;
	Velocity.y = 0;
	TextureFilePath = "Sprites/Jerome_Boss_Original.jpg";
	Position.x = 0;
	Position.y = 1500;
	Height = 640;
	Width = 640;
	Health = 100;
	FireRate = 0.2f;
	NextFire = 0;
	//GlTextureHandle = SOIL_load_OGL_texture(TextureFilePath.c_str(), SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID,
		//SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Boss(float VelocityM, std::string TextureFileP, float PositionX, float PositionY, float HeightValue, float WidthValue, float HealthValue, float FireRateValue, int BossIndex, Coord2D Offsets[3], GLuint TextureH)
//		 Inputs: Parameters to Initialize the Boss with
//	    Outputs: 
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

Boss::Boss(float VelocityM, std::string TextureFileP, float PositionX, float PositionY, float HeightValue, float WidthValue, float HealthValue, float FireRateValue, int BossIndex, Coord2D Offsets[3], GLuint TextureH)
{
	VelocityMagnitude = VelocityM;
	Velocity.x = 0;
	Velocity.y = 0;
	TextureFilePath = TextureFileP;
	Position.x = PositionX;
	Position.y = PositionY;
	Height = HeightValue;
	Width = WidthValue;
	Health = HealthValue;
	OriginalHealth = Health;
	FireRate = FireRateValue;
	BossID = BossIndex;
	NextFire = 0;
	Mode = 1;
	for (int i = 0; i < 3; i++)
	{
		SpawnOffsets[i].x = Offsets[i].x;
		SpawnOffsets[i].y = Offsets[i].y;
	}

	UI::GetInstance()->setMaxHealth(Health);

	GlTextureHandle = TextureH;

}

Boss::~Boss()
{
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: ResetHealth
//		 Inputs: N/A
//	    Outputs: Increments the bosses health counting towards regen
//	Description: This function is generally called when the player's health hits 0
//				 
//----------------------------------------------------------------------------------------------------------------------

int Boss::ResetHealth()
{
	if (Health >= (OriginalHealth - 5))
	{
		Health = OriginalHealth;
	}
	else
	{
		Health += 5;
	}
	return OriginalHealth;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Draw()
//		 Inputs: N/A
//	    Outputs: Renders the boss on the screen
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void Boss::Draw()
{
	Render(GlTextureHandle);
	UI::GetInstance()->displayBossHeath(Health);
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Update
//		 Inputs: Delta Time
//	    Outputs: Updates the behaviour of the boss each frame
//	Description: Uses a function pointer so that each boss can have it's own unique behavior
//				 
//----------------------------------------------------------------------------------------------------------------------

bool Boss::Update(DWORD Milliseconds)
{
	bool ReturnValue;
	ReturnValue = (this->*UpdatePointer[BossID])(Milliseconds);

	

	return ReturnValue;
}

void Boss::Initialize(float PositionX, float PositionY, float Velocity, int PID, GLuint TextureHandle, float InitialAngle)
{

}

//All functions below this points are specialized for each boss depending on their ID. All  the function involve the Boss's movement, the bullets they spawn which eventually constitute
//to the overall patterns each boss has

bool Boss::Boss3Update(DWORD Milliseconds)
{
	static int InitialAngle = 0;
	static int InitialAngle2 = 180;

	static int SweepAngle1 = 245;
	static int SweepAngle2 = 295;

	static int SweepIncrement = 3;
	static int SpiralStartOffset = 0;


	if (Position.x > 500 )
	{
		VelocityMagnitude = -abs(VelocityMagnitude);	
	}
	else if (Position.x <-500)
	{
		VelocityMagnitude = abs(VelocityMagnitude);
	}

	Position.x += VelocityMagnitude*(Milliseconds / 10);


	switch (Mode)
	{
		case 1:
			{
				if (NextFire < CGame::GetInstance()->GetElapsedTime())
				{

					GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 2, SweepAngle1);
					
					for (int i = 0; i < 360; i+=20)
					{
						GameObjectManager::GetInstance()->AddBullet(Position.x , Position.y, 20, Patterns::LINEAR_ANGLED, 1, InitialAngle+i);
					}
					
					SweepAngle1 += SweepIncrement;
					if (SweepAngle1 > 315 || SweepAngle1 < 225)
					{
						SweepIncrement = -SweepIncrement;
					}

					NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
					if (Health < 50)
					{
						Mode++;
					}
				}
				break;
			}

		case 2:
		{
			if (NextFire < CGame::GetInstance()->GetElapsedTime())
			{

				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 2, SweepAngle1);
				//GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 2, SweepAngle2);


				if (Health < 20)
				{
					for (int i = SpiralStartOffset; i < SpiralStartOffset + 360; i += 20)
					{
					GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 25, Patterns::INVERSE_LINEAR_ANGLED, 1, InitialAngle + i);
					}
				}

				else
				{
					for (int i = SpiralStartOffset; i < SpiralStartOffset + 360; i += 20)
					{
						GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 20, Patterns::LINEAR_ANGLED, 1, InitialAngle + i);
					}
				}

				SpiralStartOffset = (SpiralStartOffset + 5) % 90;
				SweepAngle1 += SweepIncrement;
				SweepAngle2 -= SweepIncrement;

				if (SweepAngle1 > 295 || SweepAngle1 < 245)
				{
					SweepIncrement = -SweepIncrement;
				}

				
				NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;


			}
			break;
		}

		default:
		{

		}
	}

	//if (NextFire < CGame::GetInstance()->GetElapsedTime())
	//{
	//	//Linear Angled Pattern
	//	GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, 1, 1, 270);
	//	GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, 1, 1, SweepAngle1);
	//	GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, 1, 1, SweepAngle2);
	//	
	//	//Whirlpool
	//	GameObjectManager::GetInstance()->AddBullet(Position.x + SpawnOffsets[2].x + WhirpoolSweep, Position.y + SpawnOffsets[2].y, 25, 2, 1, 0);
	//	GameObjectManager::GetInstance()->AddBullet(Position.x + SpawnOffsets[1].x - 200 - WhirpoolSweep, Position.y + SpawnOffsets[1].y, 25, 2, 1, 0);

	//	//Spiral
	//	GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 15, 1, 1, InitialAngle);
	//	GameObjectManager::GetInstance()->AddBullet(Position.x -50, Position.y, 15, 1, 1, InitialAngle2);

	//	InitialAngle = (InitialAngle + 10) % 360;
	//	InitialAngle2 = (InitialAngle2 + 10) % 360;

	//	SweepAngle1 = (SweepAngle1 + 1);
	//	SweepAngle2 = (SweepAngle2 - 1);

	//	WhirpoolSweep = (WhirpoolSweep + 10) % 2000;

	//	if (SweepAngle1>295)
	//	{
	//		SweepAngle1 = 245;
	//		SweepAngle2 = 295;
	//	}
	//	NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
	//}

	return true;
}

void Boss::TakeDamage()
{
	Health -= 1;
	if (Health < 1)
	{
		BossID = 0;
	}
	
}

bool Boss::DeathUpdate(DWORD Milliseconds)
{
	return false;
}

bool Boss::Boss1Update(DWORD Milliseconds)
{

	static int InitialAngle1[8] = { 0,45,90,135,180,225,270,315 };
	static float FireRate2 = FireRate + 0.05;
	static float NextFire2 = 0.0f;
	static int SweepAngle1 = 260, SweepAngle2 = 280;
	static int SweepIncrement1 = 1, SweepIncrement2 = -1;

	switch (Mode)
	{
	case 1:
	{
		
		if (NextFire2 < CGame::GetInstance()->GetElapsedTime())
		{
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, 270);
			GameObjectManager::GetInstance()->AddBullet(Position.x + SpawnOffsets[1].x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, 270);
			GameObjectManager::GetInstance()->AddBullet(Position.x + SpawnOffsets[2].x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, 270);


			NextFire2 = CGame::GetInstance()->GetElapsedTime() + FireRate2;
		}
		if (NextFire < CGame::GetInstance()->GetElapsedTime())
		{
			for (int i = 0; i < 8; i++)
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 2, InitialAngle1[i]);
				InitialAngle1[i] = (InitialAngle1[i] + 5) % 360;
			}

			NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
		}

		if (Health < 45)
		{
			Mode++;
		}
		break;
	}
	case 2:
	{
		if (NextFire2 < CGame::GetInstance()->GetElapsedTime())
		{
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, 270);
			GameObjectManager::GetInstance()->AddBullet(Position.x + SpawnOffsets[1].x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, SweepAngle2);
			GameObjectManager::GetInstance()->AddBullet(Position.x + SpawnOffsets[2].x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, SweepAngle1);

			SweepAngle2 = SweepAngle2 + SweepIncrement2;
			SweepAngle1 = SweepAngle1 + SweepIncrement1;

			if (SweepAngle1 > 275 || SweepAngle1 < 260)
			{
				SweepIncrement1 = -SweepIncrement1;
				SweepAngle1 += SweepIncrement1;
			}
			if (SweepAngle2 < 265 || SweepAngle2 > 280)
			{
				SweepIncrement2 = -SweepIncrement2;
				SweepAngle2 += SweepIncrement2;
			}

			NextFire2 = CGame::GetInstance()->GetElapsedTime() + FireRate2;
		}
	if (NextFire < CGame::GetInstance()->GetElapsedTime())
	{
		for (int i = 0; i < 8; i++)
		{
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 2, InitialAngle1[i]);
			InitialAngle1[i] = (InitialAngle1[i] + 5) % 360;
		}

		NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
	}
	break;
	}
	default:
	{

	}

	}

	return true;
}


bool Boss::Boss2Update(DWORD Milliseconds)
{
	static int Angle1 = 225;
	static int Angle1Increment = 1;

	static int Angle2 = 0;

	static float NextBurstFire = CGame::GetInstance()->GetElapsedTime() + 1;
	static float InternalBurstFire = NextBurstFire;
	static int Count = 0;
	static int BasePositionOffset = 0;
	static float NextFire2;

	switch (Mode)
	{
		case 1:
		{

			if (NextBurstFire < CGame::GetInstance()->GetElapsedTime())
			{
				
				Angle1 = 225;
				for (int i = -800; i < 800; i += 80)
				{
					GameObjectManager::GetInstance()->AddBullet(Position.x + i + BasePositionOffset, Position.y, 20, Patterns::LINEAR_ANGLED, 1, Angle1);
					Angle1 += 5;
				}

				if (Count < 5)
				{
					Count++;
					NextBurstFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
					BasePositionOffset = (BasePositionOffset + 20) % 200;
				}
				else
				{
					NextBurstFire = CGame::GetInstance()->GetElapsedTime() + 1;
					Count = 0;
					BasePositionOffset = (BasePositionOffset + 20) % 200;

				}
			}

			if (NextFire < CGame::GetInstance()->GetElapsedTime())
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x , Position.y, 30, Patterns::WAVE, 2, Angle2+90);
				GameObjectManager::GetInstance()->AddBullet(Position.x , Position.y, 30, Patterns::WAVE, 2, Angle2+180);
				GameObjectManager::GetInstance()->AddBullet(Position.x , Position.y, 30, Patterns::WAVE, 2, Angle2+270);
				GameObjectManager::GetInstance()->AddBullet(Position.x , Position.y, 30, Patterns::WAVE, 2, Angle2);
				Angle2 = (Angle2 + 2) % 360;
				NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
			}

			if (Health < 40)
			{
				Angle1 = 0;
				Angle2 = 0;
				NextFire2 = NextFire + 4;
				Mode++;
			}
			break;
		}
		case 2:
		{
			if (NextBurstFire < CGame::GetInstance()->GetElapsedTime())
			{

				Angle1 = 225;
				for (int i = -800; i < 800; i += 80)
				{
					GameObjectManager::GetInstance()->AddBullet(Position.x + i + BasePositionOffset, Position.y, 30, Patterns::LINEAR_ANGLED, 1, Angle1);
					Angle1 += 5;
				}

				if (Count < 5)
				{
					Count++;
					NextBurstFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
					BasePositionOffset = (BasePositionOffset + 20) % 200;
				}
				else
				{
					NextBurstFire = CGame::GetInstance()->GetElapsedTime() + 1;
					Count = 0;
					BasePositionOffset = (BasePositionOffset + 20) % 200;
					//Angle2 += 10;

				}
			}

			if (NextFire < CGame::GetInstance()->GetElapsedTime())
			{
				for (int i = 0; i < 3; i++)
				{
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 20);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 45);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 65);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 90);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 105);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 135);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 155);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 180);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 200);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 225);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 245);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 270);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 295);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 315);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y, 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 335);

				}

				if (NextFire2 > CGame::GetInstance()->GetElapsedTime())
				{
					NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
				}
				else
				{
					NextFire = CGame::GetInstance()->GetElapsedTime() + 3;
					NextFire2 = NextFire + 4;
					Angle2 = (Angle2 + 10) % 360;
				}
			}
			/*if (NextFire < CGame::GetInstance()->GetElapsedTime())
			{
				for (int i = 0; i < 3; i++)
				{
					GameObjectManager::GetInstance()->AddBullet(Position.x + SpawnOffsets[i].x, Position.y, 30, Patterns::WAVE, 1, Angle1);
					GameObjectManager::GetInstance()->AddBullet(Position.x + SpawnOffsets[i].x + 800, Position.y, 30, Patterns::WAVE, 1, Angle1);
					GameObjectManager::GetInstance()->AddBullet(Position.x + SpawnOffsets[i].x - 800, Position.y, 30, Patterns::WAVE, 1, Angle1);
					NextFire = CGame::GetInstance()->GetElapsedTime() + 0.1f;
					
				}
				Angle1 += Angle1Increment;
				if (Angle1 > 310 || Angle1 < 225)
				{
					Angle1 -= Angle1Increment;
					Angle1Increment = -Angle1Increment;
				}

			}*/
			break;
		}
		default:
		{

		}
		
	}

	return true;
}

bool Boss::Boss4Update(DWORD Milliseconds)
{
	static int Angle = 270;
	static float NextFire2 = 0;
	static int Count = 0;
	switch (Mode)
	{
		case 1:
		{
			if (NextFire < CGame::GetInstance()->GetElapsedTime())
			{
				Count++;
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::SPLIT_SHOT_CONSTANT, 1, 270);
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::SPLIT_SHOT_CONSTANT, 1, 225);
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::SPLIT_SHOT_CONSTANT, 1, 315);
				//GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::SPLIT_SHOT_CONSTANT, 1, 315);

				if (Count < 5)
				{
					NextFire = CGame::GetInstance()->GetElapsedTime() + 0.1;
				}
				else
				{
					Count = 0;
					NextFire = CGame::GetInstance()->GetElapsedTime() + 2;
				}
			}
			if (Health < 40)
			{
				Mode++;
			}
			break;
		}
		case 2:
		{
			if (NextFire < CGame::GetInstance()->GetElapsedTime())
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::SPLIT_SHOT_LEFT_FULL_RANDOM, 1, 225);
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::SPLIT_SHOT_RIGHT_FULL_RANDOM, 1, 315);
			
				NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;				
			}

			/*if (NextFire2 < CGame::GetInstance()->GetElapsedTime())
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, Angle);
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, Angle + 180);

				NextFire2 = CGame::GetInstance()->GetElapsedTime() + 0.2;

				Angle = (Angle + 5) % 360;
			}*/
			break;
		}
		default:
		{
		}
	}

	return true;

}

bool Boss::Boss5Update(DWORD Milliseconds)
{

	static int Angle = 0;
	static int InitialAngle1[8] = { 0,45,90,135,180,225,270,315 };


	switch (Mode)
	{
	case 1:
	{
		if (NextFire < CGame::GetInstance()->GetElapsedTime())
		{
			for (int i = 0; i < 8; i++)
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, InitialAngle1[i]);
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::INVERSE_LINEAR_ANGLED, 1, InitialAngle1[i]);

					InitialAngle1[i] = (InitialAngle1[i] + 5) % 360;

		/*	GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, Angle);
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, Angle + 90);
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, Angle + 180);
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, Angle + 270);

			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::INVERSE_LINEAR_ANGLED, 1, Angle);
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::INVERSE_LINEAR_ANGLED, 1, Angle + 90);
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::INVERSE_LINEAR_ANGLED, 1, Angle + 180);
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::INVERSE_LINEAR_ANGLED, 1, Angle + 270);*/
			}

			if (Health < 65)
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 20, Patterns::LINEAR_ANGLED, 2, getRangedRandom(245, 295));
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 20, Patterns::LINEAR_ANGLED, 2, getRangedRandom(245, 295));
			}

			Angle = (Angle + 5) % 360;
			NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
		}

		break;
	}
	default:
	{

	}
	}
	return true;
}

bool Boss::Boss6Update(DWORD Milliseconds)
{
	static int InitialAngle1[12] = { 0,30,60,90,120,150,180,210,240,270,300,330 };
	static float FireRate2 = FireRate + 1.0;
	static float NextFire2 = 0.0f;
	static int angle = 0;
	static int Angle2 = 0;
	static int count = 0;
	static int angleAdd = 5;
	static bool paternSwitch;
	Coord2D playerPosition = GameObjectManager::GetInstance()->ReturnPlayerPosition();

	switch (Mode)
	{
	case 1:
	{

		if (NextFire2 < CGame::GetInstance()->GetElapsedTime())
		{
			//GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::TARGET_PLAYER_SPLIT, 1, 270);
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::TARGET_PLAYER_SPLIT, 1, 225);
			//GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::TARGET_PLAYER_SPLIT, 1, 315);
			
			NextFire2 = CGame::GetInstance()->GetElapsedTime() + FireRate2;
		}

		if (NextFire < CGame::GetInstance()->GetElapsedTime())
		{
			for (int i = 0; i < 12; i++)
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 2, InitialAngle1[i]);
				InitialAngle1[i] = (InitialAngle1[i] + angleAdd) % 360;
			}
			if (count > 8)
			{
				count=0;
				angleAdd *= -1;
			}
			else
			{
				count++;
			}
			NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
		}

		if (Health < 45)
		{
			Mode++;
			count = 0;
			paternSwitch = true;
		}
		break;
	}
	case 2:
	{
		if (paternSwitch)
		{
			if (NextFire < CGame::GetInstance()->GetElapsedTime())
			{
				angle = ((atan2(playerPosition.y - Position.y, playerPosition.x - Position.x) *(180 / 3.141592653589793)));
				if (angle < 0)
				{
					angle += 360;
				}
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, angle);
				count++;
				NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
				if (count >= 3)
				{
					paternSwitch = false;
					count = 0;
				}
			}
		}
		else
		{
			if (NextFire < CGame::GetInstance()->GetElapsedTime())
			{
				int ySubtractor = 100;
				for (int i = 0; i < 3; i++)
				{
					if (i == 2)
					{
						ySubtractor = -10;
					}
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y + (i * -ySubtractor), 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 200);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y + (i * -ySubtractor), 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 225);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y + (i * -ySubtractor), 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 245);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y + (i * -ySubtractor), 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 270);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y + (i * -ySubtractor), 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 295);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y + (i * -ySubtractor), 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 315);
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y + (i * -ySubtractor), 20, Patterns::LINEAR_ANGLED, 2, Angle2 + 335);

				}
				count++;
				NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
				if (count >= 3)
				{
					paternSwitch = true;
					count = 0;
				}
			}
		}
		break;
	}
	default:
	{

	}

	}

	return true;
}

bool Boss::Boss7Update(DWORD Milliseconds)
{
	static float nextFire1 = 0;
	static float fireRate2 = FireRate + 0.05;
	static int Angle = 220;
	static int angleAdditive = 5;
	static int OtherAngleAdditive = 4;
	static int count = 0;
	static int OtherCount = 0;
	static int InitialAngle1[8] = { 325,0,90,135,225,260,270,315 };
	static int InitialAngle2[8] = { 0,45,90,135,180,225,270,315 };

	switch (Mode)
	{
	case 1:
	{
		if (NextFire < CGame::GetInstance()->GetElapsedTime())
		{
			if (Angle > 330)
			{
				angleAdditive = -5;
			}
			else if(Angle < 225)
			{
				angleAdditive = 5;
			}
			count++;
			Angle = (Angle + angleAdditive);
			if (count > 2)
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 20, Patterns::SPLIT_SHOT_RIGHT_FULL_RANDOM, 2, Angle);
				count = 0;
			}

			if (OtherCount > 8)
			{
				OtherAngleAdditive *= -1;
				OtherCount = 0;
			}

			for (int i = 0; i < 8; i++)
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 22, Patterns::WAVE, 1, InitialAngle2[i]);
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 22, Patterns::INVERSE_WAVE, 1, InitialAngle2[i]);

				InitialAngle2[i] = (InitialAngle2[i] + OtherAngleAdditive) % 360;
			}
			OtherCount++;
			NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
		}
		if (Health < 40)
		{
			Mode++;
			count = 0;
		}
		break;
	}
	case 2:
	{
		if (nextFire1 < CGame::GetInstance()->GetElapsedTime())
		{
			if (count <= 10)
			{
				for (int i = 0; i < 8; i++)
				{
					GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 22, Patterns::WAVE, 1, InitialAngle2[i]);
					GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 22, Patterns::INVERSE_WAVE, 1, InitialAngle2[i]);

					InitialAngle2[i] = (InitialAngle2[i] + 3) % 360;
				}
			}
			else
			{
				int ySubtractor = 100;
				for (int i = 0; i < 3; i++)
				{
					if (i == 2)
					{
						ySubtractor = -10;
					}
					GameObjectManager::GetInstance()->AddBullet(Position.x + (i * 100), Position.y + (i * -ySubtractor), 10, Patterns::TARGET_PLAYER_SPLIT, 1, 270);
				}
			}
			if (count > 12)
			{
				count = 0;
			}

			if (Health < 10)
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 10, Patterns::TARGET_PLAYER_SPLIT, 1, 270);
			}
			count++;
			//Angle = (Angle + 5) % 360;
			nextFire1 = CGame::GetInstance()->GetElapsedTime() + fireRate2;
		}

		break;
	}
	default:
	{

	}
	}
	return true;
}

bool Boss::Boss8Update(DWORD Milliseconds)
{
	static int angle= 0;
	static float FireRate2 = FireRate + 0.5;
	static float NextFire2 = 0.0f;
	static float FireRate3 = FireRate + 1.0;
	static float NextFire3 = 0.0f;
	Coord2D playerPosition = GameObjectManager::GetInstance()->ReturnPlayerPosition();

	angle = (angle + 10) % 360;
	GameObjectManager::GetInstance()->AddBullet(Position.x + 40, Position.y + 40, 20, Patterns::LINEAR_ANGLED, 1, angle);

	if (NextFire2 < CGame::GetInstance()->GetElapsedTime())
	{
		GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::SPLIT_SHOT_CONSTANT, 1, getRangedRandom(245, 295));
		NextFire2 = CGame::GetInstance()->GetElapsedTime() + FireRate2;
	}

	if (NextFire3 < CGame::GetInstance()->GetElapsedTime())
	{
		if (Health < 30)
		{
			int playerAngle = ((atan2(playerPosition.y - Position.y, playerPosition.x - Position.x) *(180 / 3.141592653589793)));
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 2, playerAngle);
		}
		NextFire3 = CGame::GetInstance()->GetElapsedTime() + FireRate3;
	}
	return true;
}


bool Boss::Boss9Update(DWORD Milliseconds)
{
	//static int InitialAngle1[16] = { 0,20,45,65,90,115,135,155,180,205,225,245,270,295,315,335 };
	static int InitialAngle1[8] = { 0,45,90,135,180,225,270,315};
	static int SpiralAngle = 0;
	static int InitialAngle = 0;

	static float NextFire2 = CGame::GetInstance()->GetElapsedTime() + 3.0f;
	static float NextFire3 = CGame::GetInstance()->GetElapsedTime() + 3.0f;
	static int Count = 0;
	static int Angle1=225;

	static float NextBurstFire = CGame::GetInstance()->GetElapsedTime() + 1;
	if (Position.x > 700)
	{
		VelocityMagnitude = -abs(VelocityMagnitude);
	}
	else if (Position.x <-700)
	{
		VelocityMagnitude = abs(VelocityMagnitude);
	}

	Position.x += VelocityMagnitude*(Milliseconds / 10);

	switch (Mode)
	{
	case 1:
	{
		if (NextFire < CGame::GetInstance()->GetElapsedTime())
		{

			for (int i = 0; i < 8; i++)
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30/*getRangedRandom(20, 40)*/, Patterns::LINEAR_ANGLED, 1, InitialAngle1[i]);
				
				InitialAngle1[i] = (InitialAngle1[i] + 3) % 360;
			}
			
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30/*getRangedRandom(20, 40)*/, Patterns::INVERSE_LINEAR_ANGLED, 1, Angle1);
			Angle1 = (Angle1 + 10) % 360;
			NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
			
		}

		if (NextFire2 < CGame::GetInstance()->GetElapsedTime())
		{
			for (int i = SpiralAngle; i < SpiralAngle + 360; i += 20)
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 20, Patterns::LINEAR_ANGLED, 2, InitialAngle + i);
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 20, Patterns::INVERSE_LINEAR_ANGLED, 2, InitialAngle + i);
			}
			NextFire2 = CGame::GetInstance()->GetElapsedTime() + 0.4;
			SpiralAngle = (SpiralAngle + 5) % 90;
		}
		if (Health < 75)
		{
			Mode++;
		}
		break;
	}
	case 2:
	{
		if (NextFire < CGame::GetInstance()->GetElapsedTime())
		{
			for (int i = 0; i < 8; i++)
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30/*getRangedRandom(20, 30)*/, Patterns::INVERSE_LINEAR_ANGLED, 1, InitialAngle1[i]);
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30/*getRangedRandom(20, 30)*/, Patterns::LINEAR_ANGLED, 1, InitialAngle1[i]);

				InitialAngle1[i] = (InitialAngle1[i] + 3) % 360;
			}

			
			Angle1 = (Angle1 + 10) % 360;
			NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;

		}

		if (NextFire2 < CGame::GetInstance()->GetElapsedTime())
		{
			for (int i = SpiralAngle; i < SpiralAngle + 360; i += 20)
			{
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::INVERSE_LINEAR_ANGLED, 2, InitialAngle + i);
				GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 2, InitialAngle + i);
			}
			
			NextFire2 = CGame::GetInstance()->GetElapsedTime() + 0.4;
			SpiralAngle = (SpiralAngle + 5) % 90;
			
		}
		if (NextFire3 < CGame::GetInstance()->GetElapsedTime())
		{
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::SPLIT_SHOT_CONSTANT, 1, getRangedRandom(250, 300));
			NextFire3 = CGame::GetInstance()->GetElapsedTime() + 2;
		}
	}
	default:
	{
	}
	}

	return true;

}

bool Boss::Boss10Update(DWORD Milliseconds)
{

	static float NextFire2 = 0;
	if (NextFire < CGame::GetInstance()->GetElapsedTime())
	{
		GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 50, Patterns::WHIRLPOOL, 2, 270);
		GameObjectManager::GetInstance()->AddBullet(Position.x + SpawnOffsets[2].x, Position.y, 50, Patterns::WHIRLPOOL, 2, 270);
		for (int i = 0; i < 30; i++)
		{
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 1, getRangedRandom(0, 360));
		}

		NextFire= CGame::GetInstance()->GetElapsedTime() + FireRate;
	}

	if (NextFire2 < CGame::GetInstance()->GetElapsedTime())
	{
		for (int i = 0; i < 360; i+=5)
		{
			GameObjectManager::GetInstance()->AddBullet(Position.x, Position.y, 30, Patterns::LINEAR_ANGLED, 2, i);
		}

		NextFire2 = CGame::GetInstance()->GetElapsedTime() + 3;
	}
	return true;
}