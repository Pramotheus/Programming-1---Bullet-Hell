#include <windows.h>											// Header File For Windows
#include <Xinput.h>												// Header file for xbox joystick
#include <iostream>
#include "baseTypes.h"
#include "InputManager.h"
InputManagerC* InputManagerC::sInstance = NULL;

InputManagerC *InputManagerC::CreateInstance()
{
	if(sInstance!=NULL)return sInstance;
	else

	sInstance = new InputManagerC(1);
	return sInstance;
}

// Constrocter of the input manager classs for xbox joystick with controller number
InputManagerC::InputManagerC(int playerNumber)
{
	// Set the Controller Number (we use only one controller and is defined by the single object created )
	controllerNumber = playerNumber - 1;
	playerMoveForwardBack = 0;
	playerMoveLeftRight = 0;
	playerFire = false;
	quitGame = false;
}

//function to clearout already stored state and return current state value
XINPUT_STATE InputManagerC::GetState()
{
	//zero out the memory of the controller state for cases when controller diconnect without warning
	ZeroMemory(&controllerState, sizeof(XINPUT_STATE));

	// Get the state from predefined XINPUT library and return the value
	XInputGetState(controllerNumber, &controllerState);

	return controllerState;
}

bool InputManagerC::IsConnected()
{
	//zero out the memory of the controller state for cases when controller diconnect without warning
	ZeroMemory(&controllerState, sizeof(XINPUT_STATE));

	// Get the state from redefined XINPUT library function to check for connection of joystick
	DWORD Result = XInputGetState(controllerNumber, &controllerState);

	//Error_success #define from window.h include
	if (Result == ERROR_SUCCESS)
	{
		return true;
	}
	else
	{
		return false;
	}
}

void InputManagerC::Vibrate(int leftVal, int rightVal)
{
	// Create a Vibraton State from the predefined Xinput library struct to use on the joystick
	XINPUT_VIBRATION Vibration;

	// Zeroise the Vibration
	ZeroMemory(&Vibration, sizeof(XINPUT_VIBRATION));

	// Set the Vibration Values (0 is lowest value and 65535 the highest value)
	Vibration.wLeftMotorSpeed = leftVal;
	Vibration.wRightMotorSpeed = rightVal;

	// Vibrate the controller
	XInputSetState(controllerNumber, &Vibration);
}

//Fuction returns 1 for forword movement, -1 for backword movement and 0 for idle
int InputManagerC::GetForwardBackMovement()
{
	return playerMoveForwardBack;
}

//Fuction returns 1 for right movement, -1 for Left movement and 0 for idle
int InputManagerC::GetLeftRightMovement()
{
	return playerMoveLeftRight;
}

//Fuction returns true when fire action is activated
bool InputManagerC::IsPlayerFireActive()
{
	return playerFire;
}

//returns true if quit key has been pressed
bool InputManagerC::IsQuitPressed()
{
	return quitGame;
}

void InputManagerC::init()
{
	//setup inputmode to nonbuffer mode to get input as soon as key hit
	HANDLE hstdin;
	DWORD  mode;

	hstdin = GetStdHandle(STD_INPUT_HANDLE);
	GetConsoleMode(hstdin, &mode);
	SetConsoleMode(hstdin, ENABLE_ECHO_INPUT | ENABLE_PROCESSED_INPUT);
}

void InputManagerC::update()
{
	//check if joystick is connected
	if (sInstance->IsConnected())
	{
		//declare variable to hold values for Left X and Y axis values
		float LeftXaxis = sInstance->GetState().Gamepad.sThumbLX;
		float LeftYaxis = sInstance->GetState().Gamepad.sThumbLY;


		if (LeftXaxis > MINIMUM_OFFSET_OF_ANALOG_FOR_MOVE)			//if left analog is moved to left set move player left or right to 1
		{
			playerMoveLeftRight = 1;
		}
		else if (LeftXaxis < -MINIMUM_OFFSET_OF_ANALOG_FOR_MOVE)	//if left analog is moved to right set move player left or right to -1
		{
			playerMoveLeftRight = -1;
		}
		else
		{
			playerMoveLeftRight = 0;								//if left analog is not moved set move player left or right to 0
		}

		if (LeftYaxis > MINIMUM_OFFSET_OF_ANALOG_FOR_MOVE)			//if left analog is moved forword set move player forword or backword to 1
		{
			playerMoveForwardBack = 1;
		}
		else if (LeftYaxis < -MINIMUM_OFFSET_OF_ANALOG_FOR_MOVE)	//if left analog is moved back set move player forword or backword to -1
		{
			playerMoveForwardBack = -1;
		}
		else
		{
			playerMoveForwardBack = 0;								//if left analog is not moved set move player forword or backword to 0
		}

		if ((sInstance->GetState().Gamepad.wButtons & XINPUT_GAMEPAD_A) || (sInstance->GetState().Gamepad.bRightTrigger))
		{
			playerFire = true;										//if A button or right trigger is pressed set fire to active
		}
		else
		{
			playerFire = false;										//if both are not pressed set fire to false
		}

		if (sInstance->GetState().Gamepad.wButtons & XINPUT_GAMEPAD_BACK)
		{
			quitGame = true;										//if 'back' button is pressed set quit to true
		}
		else
		{
			quitGame = false;
		}
	}
	else
	{
		//if joystic is not connected use keyboard inputs
		//used for debug purposes only

		//read charecter pressed
		int input = std::cin.get();

		if (input == 'a')						//if a charecter pressed set move player forword or backword to 1
		{
			playerMoveLeftRight = 1;
		}
		else if (input == 'd')					//if d charecter pressed set move player forword or backword to -1
		{
			playerMoveLeftRight = -1;
		}
		else
		{
			playerMoveLeftRight = 0;			//if no charecter is pressed set move player forword or backword to 0
		}

		if (input == 'w')						//if w charecter is pressed set move player left or right to 1
		{
			playerMoveForwardBack = 1;
		}
		else if (input == 's')					//if s charecter is pressed set move player left or right to -1
		{
			playerMoveForwardBack = -1;
		}
		else
		{
			playerMoveForwardBack = 0;			//if no charecter is pressed set move player left or right to 0
		}

		if (input == ' ')						//if space is pressed set move player left or right to 0
		{
			playerFire = true;
		}
		else
		{
			playerFire = false;					//if space is not pressed set fire to false
		}

		if (input == 'q')
		{
			quitGame = true;					//if q is pressed set quit to active
		}
	}
}
