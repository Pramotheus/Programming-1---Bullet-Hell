#pragma once
#include<iostream>
#include<vector>
#pragma once
#include<random>
#include"Star.h"
#include"SOIL.h"
#include"glut.h"
#include"gl\gl.h"

class StarField
{
public:
	StarField();
	StarField(int, int);
	~StarField();

	void Draw();
	void Update();
	void ShutDown();
	void ToggleHyperSpace();

private:
	std::vector<Star*> SmallStars;
	std::vector<Star*> MediumStars;
	std::vector<Star*> LargeStars;

	/*Star* Temporary;
	GLuint TempTexture;*/

	std::default_random_engine XRandom;
	std::default_random_engine YRandom;

	std::uniform_int_distribution<int> XDistribution;
	std::uniform_int_distribution<int> YDistribution;

	Coord2D Bounds;
	int MaxStars[3];
	GLuint StarTexture;
	int VelocityFactor;
};

