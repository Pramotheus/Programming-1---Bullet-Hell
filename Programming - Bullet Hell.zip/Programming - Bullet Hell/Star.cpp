#pragma once
#include "Star.h"
#include"glut.h"
#include"gl\gl.h"


Star::Star()
{
}


Star::~Star()
{
}

Star::Star(float XPosition, float YPosition, int XSize, int YSize)
{
	Position.x = XPosition;
	Position.y = YPosition;

	Width = XSize;
	Height = YSize;
}

void Star::SetPosition(float XPosition, float YPosition)
{
	Position.x = XPosition;
	Position.y = YPosition;
}

void Star::AddYPosition(float Value)
{
	Position.y += Value;
}

Coord2D Star::GetPosition()
{
	return Position;
}

void Star::Draw()
{

	GLfloat XPositionLeft = Position.x - (Width / 2);
	GLfloat XPositionRight = Position.x + (Width / 2);
	GLfloat YPositionTop = Position.y + (Height / 2);
	GLfloat YPositionBottom = Position.y - (Height / 2);

	/*GLfloat XTextureCoord = 1;
	GLfloat YTextureCoord = 1;*/

	glColor4ub(0xFF, 0xFF, 0xFF, 0xFF);

	//Bottom Left Vertex
	glTexCoord2f(0, 0);
	glVertex3f(XPositionLeft, YPositionBottom, 0);

	//Bottom Right Vertex
	glTexCoord2f(1, 0);
	glVertex3f(XPositionRight, YPositionBottom, 0);

	//Top Right Vertex
	glTexCoord2f(1, 1);
	glVertex3f(XPositionRight, YPositionTop, 0);

	//Top Left Vertex
	glTexCoord2f(0, 1);
	glVertex3f(XPositionLeft, YPositionTop, 0);

}