#include "Text.h"

UI* UI::textInstance = NULL;
int UI::MaxHealth = 100;
UI *UI::CreateInstance()
{
	if (textInstance != NULL)return textInstance;
	else

		textInstance = new UI();
	return textInstance;
}

UI::UI()
{
	CreditsText.push_back("Developed By,");
	CreditsText.push_back("Karthik and Jerome");
	CreditsText.push_back("To be Continued");
	CreditsText.push_back("Programming II");

}

void UI::displayScore(int score)
{
	glDisable(GL_TEXTURE_2D);

	char buffer[50];
	sprintf(buffer, "SCORE : %d ", score);
	std::string String = buffer;
	glColor3f(0, 1, 1);
	glRasterPos2i(1450, 1850);
	for (int i = 0; i<String.size(); i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, (int)String[i]);
	}

}

void UI::displayBossHeath(int health)
{
	glDisable(GL_TEXTURE_2D);
	glColor3f(0.2f, 0.2f, 0.2f);
	glRectf(-1320.0f, 1850, 1320.0f, 1920);

	//glDisable(GL_TEXTURE_2D);
	int reducedHealth = ((2600 * health) / MaxHealth);
	glColor3f(1.0f, 0.0f, 0.0f);
	glRectf((-reducedHealth / 2), 1870, (reducedHealth/2), 1900);
}

void UI::displayPlayerHealth(int health, float playerPositionX, float playerPositionY)
{
	static int MaxPlayerHealth = health;
	glDisable(GL_TEXTURE_2D);
	glColor3f(0.3f, 0.2f, 0.2f);
	glRectf(playerPositionX - 67, playerPositionY - 125 , playerPositionX + 67, playerPositionY - 95);

	int reducedHealth = ((128 * health) / MaxPlayerHealth);
	glColor3f(0.0f, 1.0f, 0.0f);
	glRectf(playerPositionX + (-reducedHealth / 2), playerPositionY - 120, playerPositionX + (reducedHealth / 2), playerPositionY - 100);
}

UI::~UI()
{
}

void UI::setMaxHealth(int value)
{
	MaxHealth = value;
}

void UI::DisplayCredits()
{
	glDisable(GL_TEXTURE_2D);
	glColor3f(1.0f, 1.0f, 1.0f);

	glRasterPos2i(-200, 200);

	for (int i = 0; i < CreditsText[0].length(); i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (CreditsText[0])[i]);
	}

	glRasterPos2i(-200, 0);

	for (int i = 0; i < CreditsText[1].length(); i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (CreditsText[1])[i]);
	}

}

void UI::DisplayFinaleText()
{
	glDisable(GL_TEXTURE_2D);
	glColor3f(1.0f, 1.0f, 1.0f);

	glRasterPos2i(-200, 200);

	for (int i = 0; i < CreditsText[2].length(); i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (CreditsText[2])[i]);
	}

	glRasterPos2i(-200, 0);

	for (int i = 0; i < CreditsText[3].length(); i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (CreditsText[3])[i]);
	}
}

void UI::Shutdown()
{
	for (std::vector<std::string>::iterator it = CreditsText.begin(); it != CreditsText.end(); it++)
	{
		CreditsText.erase(it);
	}
}
