#pragma once
#include"GameObject.h"

class Player: public GameObject
{
public:
	Player();
	~Player();
	bool Update(DWORD);
	void Draw();
	void Initialize(float PositionX, float PositionY, float Velocity, int PID, GLuint TextureHandle, float InitialAngle);
	int ReduceHealth(int Amount);
	void ResetHealth();
	

private:
	int  Score; // Just putting this here now
	bool IsInvinicible;
	float FireRate;
	int Health;

	float GetLinearXVelocity();
	float GetLinearYVelocity();
};

