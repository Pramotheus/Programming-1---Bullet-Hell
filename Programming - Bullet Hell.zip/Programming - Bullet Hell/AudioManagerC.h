#pragma once
#ifndef AUDIO_MANAGER_C
#define AUDIO_MANAGER_C

#include <vector>
#include "Audio.h"

#endif

enum SoundIndex
{
	PlayerLaser,
	PlayerCollision,
	BackgroundTheme,
	DunDunDun
};

class AudioManagerC
{
private:
	static AudioManagerC *audioManagerInstance;


	Audio* mAudio;

	std::vector<Sound*> soundVector;

public:
	AudioManagerC() {};

	static AudioManagerC *CreateInstance();
	static AudioManagerC *GetInstance() { return audioManagerInstance; };

	void Init();
	void Update();
	void shutdown();

	void PlaySounds(SoundIndex value, bool isLoop=false);

	~AudioManagerC() {};
};

