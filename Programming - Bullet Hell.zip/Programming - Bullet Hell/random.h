float getRangedRandom(float min, float max);
int getRangedRandom(int min, int max);
