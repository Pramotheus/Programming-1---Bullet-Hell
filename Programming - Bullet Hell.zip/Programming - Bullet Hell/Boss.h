#pragma once
#include"GameObject.h"


enum Patterns
{
	PLAYER_LINEAR,
	LINEAR_ANGLED,
	INVERSE_LINEAR_ANGLED,
	WHIRLPOOL,
	WAVE,
	INVERSE_WAVE,
	SPLIT_SHOT_LEFT_FULL_RANDOM,
	SPLIT_SHOT_RIGHT_FULL_RANDOM,
	SPLIT_SHOT_CONSTANT,
	TARGET_PLAYER,
	TARGET_PLAYER_SPLIT
};

class Boss: public GameObject
{
public:
	Boss();
	Boss(float VelocityM, std::string TextureFileP, float PositionX, float PositionY, float Height, float Width, float Health, float FireRate, int BossID, Coord2D Offsets[3], GLuint TextureH);
	~Boss();
	void Initialize(float PositionX, float PositionY, float Velocity, int PID, GLuint TextureHandle, float InitialAngle);
	void TakeDamage();
	int ResetHealth();
	

private:
	Coord2D SpawnOffsets[3];
	void Draw();
	bool Update(DWORD Milliseconds);

	bool DeathUpdate(DWORD);
	bool Boss1Update(DWORD);
	bool Boss2Update(DWORD);
	bool Boss3Update(DWORD);
	bool Boss4Update(DWORD);
	bool Boss5Update(DWORD);
	bool Boss6Update(DWORD);
	bool Boss7Update(DWORD);
	bool Boss8Update(DWORD);
	bool Boss9Update(DWORD);
	bool Boss10Update(DWORD);

	int OriginalHealth;
	int Health;
	int BossID;
	int Mode;
	float FireRate;
	float NextFire;
	
	bool(Boss::*UpdatePointer[11])(DWORD) = { &Boss::DeathUpdate, &Boss::Boss1Update ,&Boss::Boss2Update,&Boss::Boss3Update, &Boss::Boss4Update, &Boss::Boss5Update, &Boss::Boss6Update,
												&Boss::Boss7Update,&Boss::Boss8Update, &Boss::Boss9Update, &Boss::Boss10Update, };			//Make sure to adjust values accordingly
};

