#pragma once
#define GAME_CPP
#include <windows.h>											// Header File For Windows
#include <stdio.h>												// Header File For Standard Input / Output
#include <stdarg.h>												// Header File For Variable Argument Routines
#include <math.h>												// Header File For Math Operations
#include<fstream>
#include <gl\gl.h>												// Header File For The OpenGL32 Library
#include <gl\glu.h>												// Header File For The GLu32 Library
#include "glut.h"
#include "baseTypes.h"
#include "openglframework.h"	
#include "gamedefs.h"
#include "collInfo.h"
#include "object.h"
#include "ball.h"
#include "field.h"
#include "random.h"
//#include "gameObjects.h"
#include "openGLStuff.h"
#include "game.h"
#include "StateManager.h"
#include "BallManager.h"
#include "FieldManager.h"
#include "InputManager.h"
#include "SpriteDemoManager.h"
#include "GameObjectManager.h"
#include "Text.h"
#include "AudioManagerC.h"
#include "MainMenu.h"

// Declarations
const char8_t CGame::mGameTitle[]="Programming 1 Bullet Hell";
CGame* CGame::sInstance=NULL;
double CGame::ElapsedTime = 0.0f;
std::vector<BossSpawnData> CGame::SpawnData;
int CGame::CurrentBossIndex;
int CGame::Score;
int CGame::Mode;
bool CGame::EndGame;
float CGame::TransitionEndTime;
StarField* CGame::SField = nullptr;

BOOL Initialize (GL_Window* window, Keys* keys)					// Any OpenGL Initialization Goes Here
{
	initOpenGLDrawing(window,keys,0.0f, 0.0f, 0.0f);
	CGame::CreateInstance();
	CGame::GetInstance()->InitializeBossData();
	CGame::GetInstance()->init();
	
	return TRUE;						
}

void CGame::init()
{
	//BallManagerC::CreateInstance();
	//StateManagerC::CreateInstance();
	//FieldManagerC::CreateInstance();
	//SpriteDemoManagerC::CreateInstance();
	Score = 0;

	SField = new StarField(1950,1950);

	InputManagerC::CreateInstance();
	GameObjectManager::CreateInstance();					//New Code
	InputManagerC::GetInstance()->init();
	AudioManagerC::CreateInstance();
	AudioManagerC::GetInstance()->Init();
	MainMenu::CreateInstance();
	UI::CreateInstance();
	CGame::GetInstance()->SField->ToggleHyperSpace();
	Mode = 0;
}
void CGame::UpdateFrame(DWORD milliseconds)			
{
	ElapsedTime += (milliseconds/1000.0f);
	keyProcess();
	SField->Update();

	switch (Mode)
	{
	case 0:
	{
		InputManagerC::GetInstance()->update();
		AudioManagerC::GetInstance()->Update();
		MainMenu::GetInstance()->Update();
		break;
	}
	case 1:
	{
		InputManagerC::GetInstance()->update();
		AudioManagerC::GetInstance()->Update();
		GameObjectManager::GetInstance()->UpdateAllObjects(milliseconds);
		GameObjectManager::GetInstance()->PerformCollisions();
		break;
	}
	case 2:
	{
		InputManagerC::GetInstance()->update();
		AudioManagerC::GetInstance()->Update();
		GameObjectManager::GetInstance()->UpdateOnlyPlayer(milliseconds);

		if (CGame::GetInstance()->GetElapsedTime() > CGame::GetInstance()->TransitionEndTime)
		{
			Mode = 1;
			CGame::GetInstance()->SField->ToggleHyperSpace();
			GameObjectManager::GetInstance()->EmptyPlayerBullets();			
		}
		break;
	}
	case 3:
	{
		if (CGame::GetInstance()->GetElapsedTime() < CGame::GetInstance()->TransitionEndTime)
		{
			InputManagerC::GetInstance()->update();
			AudioManagerC::GetInstance()->Update();
			GameObjectManager::GetInstance()->UpdateOnlyPlayer(milliseconds);
		}
		else
		{
			GameObjectManager::GetInstance()->SpawnFinalBoss();
			AudioManagerC::GetInstance()->PlaySounds(SoundIndex::DunDunDun);
		}
		break;
	}
	case 4:
	{
		InputManagerC::GetInstance()->update();
		AudioManagerC::GetInstance()->Update();
		if (InputManagerC::GetInstance()->IsQuitPressed() != 0)
		{
			RestartGame();
		}
		break;
	}
	default:
	{

	}
	}
	
}

void CGame::DrawScene(void)											
{
	startOpenGLDrawing();
	
	UI::GetInstance()->displayScore(Score);
	SField->Draw();
	switch (Mode)
	{
	case 0:
	{
		MainMenu::GetInstance()->Draw();
		break;
	}
	case 1:
	{
		GameObjectManager::GetInstance()->DrawAllObjects();
		break;
	}
	case 2:
	{
		GameObjectManager::GetInstance()->DrawOnlyPlayerObject();
		break;
	}
	case 3:
	{
		GameObjectManager::GetInstance()->DrawOnlyPlayerObject();
		UI::GetInstance()->DisplayCredits();
		break;
	}
	case 4:
	{
		UI::GetInstance()->DisplayFinaleText();
		break;
	}
	default:
	{

	}
	}

}


CGame *CGame::CreateInstance()
{
	sInstance = new CGame();
	return sInstance;
}
void CGame::shutdown()
{
	GameObjectManager::GetInstance()->Shutdown();
	delete GameObjectManager::GetInstance();
	AudioManagerC::GetInstance()->shutdown();
	delete AudioManagerC::GetInstance();
	SField->ShutDown();
	delete SField;
	delete InputManagerC::GetInstance();
	delete UI::GetInstance();
}
void CGame::DestroyGame(void)
{

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: GetElapsedTime()
//		 Inputs: N/A
//	    Outputs: Return elapsed time
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

double CGame::GetElapsedTime()
{
	return ElapsedTime;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: AddScore
//		 Inputs: Value to add
//	    Outputs: Increase score
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void CGame::AddScore(int Value)
{
	Score += Value;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: InitializeBossData()
//		 Inputs: N/A
//	    Outputs: Initializes Data from the boss text file
//	Description: The data is then stored in BossSpawn Data stucture
//				 
//----------------------------------------------------------------------------------------------------------------------

void CGame::InitializeBossData()
{
	std::ifstream BossDataFile;
	std::string LineString;
	char TempTextureString[50];

	BossSpawnData TempData;
	BossDataFile.open("BossSpawnData.txt", std::ios::in);

	while (std::getline(BossDataFile, LineString))
	{
		sscanf_s(LineString.c_str(), "%f %f %f %f %f %f %f %d %f %f %f %f %f %f %s", &TempData.Position.x, &TempData.Position.y, &TempData.VelocityMagnitude, &TempData.Width, &TempData.Height,
			&TempData.Health, &TempData.FireRate, &TempData.BossID, &TempData.SpawnOffsets[0].x, &TempData.SpawnOffsets[0].y,
			&TempData.SpawnOffsets[1].x, &TempData.SpawnOffsets[1].y, &TempData.SpawnOffsets[2].x, &TempData.SpawnOffsets[2].y,&TempTextureString, 50);

		TempData.TextureFilePath = TempTextureString;
		SpawnData.push_back(TempData);
	}

	CurrentBossIndex = 0;

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: GetBossData()
//		 Inputs: N/A
//	    Outputs: Get the next boss's data
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

BossSpawnData CGame::GetBossData()
{
	if (CurrentBossIndex >= SpawnData.size()-1)
	{
		CurrentBossIndex = SpawnData.size() - 1;
		EndGame = true;
		return SpawnData[CurrentBossIndex];
	}
	else
	{
		CurrentBossIndex++;
		return SpawnData[CurrentBossIndex - 1];
	}
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: EndGameReached()
//		 Inputs: N/A
//	    Outputs: Returns the state of the game
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

bool CGame::EndGameReached()
{
	return EndGame;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: ActivateTransitionMode()
//		 Inputs: N/A
//	    Outputs: Activates Hyper Space mode
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void CGame::ActivateTransitionMode()
{
	Mode = 2;
	TransitionEndTime = CGame::GetInstance()->GetElapsedTime() + 2;
	CGame::GetInstance()->SField->ToggleHyperSpace();
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: StartGame()
//		 Inputs: N/A
//	    Outputs: Starts the game
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void CGame::StartGame()
{
	//CurrentBossIndex = 0;
	ActivateTransitionMode();
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: InitiateCreditsMode()
//		 Inputs: Starts Credits Sequence
//	    Outputs: 
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void CGame::InitiateCreditsMode()
{
	Mode = 3;
	TransitionEndTime = CGame::GetInstance()->GetElapsedTime() + 2.5f;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: EndGameScreen()
//		 Inputs: N/A
//	    Outputs: Set the mode to final screen of the game
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void CGame::EndGameScreen()
{
	Mode = 4;

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: RestartGame()
//		 Inputs: N/A
//	    Outputs: Restarts the game
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void CGame::RestartGame()
{
	if (Mode == 2)
	{
		CGame::GetInstance()->SField->ToggleHyperSpace();
	}
	CurrentBossIndex = 0;
	Score = 0;
	EndGame = false;
	GameObjectManager::GetInstance()->ResetObjects();
	CGame::GetInstance()->SField->ToggleHyperSpace();
	Mode = 0;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: ReturnTexturePaths()
//		 Inputs: N/A
//	    Outputs: Return the a vector of strings which contains all the texture paths
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

std::vector<std::string> CGame::ReturnTexturePaths()
{
	std::vector<BossSpawnData>::iterator it = SpawnData.begin();
	std::vector<std::string> TexturePaths;

	for (; it != SpawnData.end(); it++)
	{
		TexturePaths.push_back(it->TextureFilePath);
	}

	return TexturePaths;
}