#pragma once
#include<Xinput.h>

#ifndef INPUT_MANAGER_H
#define INPUT_MANAGER_H
#endif

#pragma comment(lib, "XInput.lib")

#define MINIMUM_OFFSET_OF_ANALOG_FOR_MOVE	10000

class InputManagerC
{
public:
	static InputManagerC	*CreateInstance();
	static InputManagerC	*GetInstance() {return sInstance;};
	void					init();
	void					update();
	Coord2D*				getCurrentMousePosition(){};

	//Fuction used to set vibration on controller
	void					Vibrate(int leftVal = 0, int rightVal = 0);

	//functions used to get movement of player
	int						GetForwardBackMovement();
	int						GetLeftRightMovement();

	//Function used to get player fire active
	bool					IsPlayerFireActive();

	//fuction returns quit true or false
	bool					IsQuitPressed();

private:
	InputManagerC			(int playerNumber);
	static InputManagerC	*sInstance;

	_XINPUT_STATE			GetState();
	bool					IsConnected();

	_XINPUT_STATE			controllerState;
	int						controllerNumber;

	//variables used to set for player movement and shot
	int						playerMoveForwardBack;
	int						playerMoveLeftRight;
	bool					playerFire;
	bool					quitGame;
	
};
