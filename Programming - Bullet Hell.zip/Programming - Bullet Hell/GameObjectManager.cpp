#pragma once
#include "GameObjectManager.h"
#include "Player.h"
#include "Boss.h"
#include<algorithm>
#include"game.h"
#include"AudioManagerC.h"

GameObjectManager* GameObjectManager::GManagerInstance = nullptr;

GameObjectManager::GameObjectManager()
{

}


GameObjectManager::~GameObjectManager()
{
}


//---------------------------------------------------------------------------------------------------------------------
//Function Name: CreateInstance()
//		 Inputs: N/A
//	    Outputs: Creates the instance of the GameObjectManager class
//	Description: Creates the instance and calls the initialize function to initialize various members
//				 
//----------------------------------------------------------------------------------------------------------------------
GameObjectManager* GameObjectManager::CreateInstance()
{
	if (GManagerInstance == nullptr)
	{
		GManagerInstance = new GameObjectManager();
		//GManagerInstance->BPool = new BulletPool();
		
	}
	GameObjectManager::GetInstance()->Initialize();
	return GManagerInstance;
}


//---------------------------------------------------------------------------------------------------------------------
//Function Name: GetInstance()
//		 Inputs: N/A
//	    Outputs: Returns the instance of the class
//	Description: Returns the instance of the class
//				 
//----------------------------------------------------------------------------------------------------------------------
GameObjectManager* GameObjectManager::GetInstance()
{
	return GManagerInstance;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: DrawAllObjects()
//		 Inputs: N/A
//	    Outputs: Render objects to the screen
//	Description: Calls the draw functions of all the objects in the scene so they maybe rendered
//				
//----------------------------------------------------------------------------------------------------------------------
void GameObjectManager::DrawAllObjects()
{
	std::vector<GameObject*>::iterator it;
	for (it = GameObjectList.begin(); it != GameObjectList.end(); it++)
	{
		(*it)->Draw();
	}

	if (BPool->ActiveBullets.size() > 0)
	{
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, BPool->ActiveBullets[0]->GetTextureHandle());
		glBegin(GL_QUADS);

		for (it = BPool->ActiveBullets.begin(); it != BPool->ActiveBullets.end(); it++)
		{
			(*it)->Draw();
		}

		glEnd();
	}

	if (VioletBPool->ActiveBullets.size() > 0)
	{
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, VioletBPool->ActiveBullets[0]->GetTextureHandle());
		glBegin(GL_QUADS);

		for (it = VioletBPool->ActiveBullets.begin(); it != VioletBPool->ActiveBullets.end(); it++)
		{
			(*it)->Draw();
		}

		glEnd();
	}

	if (PlayerBPool->ActiveBullets.size() > 0)
	{
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, PlayerBPool->ActiveBullets[0]->GetTextureHandle());
		glBegin(GL_QUADS);

		for (it = PlayerBPool->ActiveBullets.begin(); it != PlayerBPool->ActiveBullets.end(); it++)
		{
			(*it)->Draw();
		}

		glEnd();
	}
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: UpdateAllObjects(DWORD)
//		 Inputs: DWORD for Delta Time
//	    Outputs: Updates all objects in the scene according to their respective behaviors, Handles deletion/removal as well the call to spawning new bosses
//	Description: Calls the update function of all objects of the scene and also handles deletion/removal of the objects if their updates returned false
//				
//----------------------------------------------------------------------------------------------------------------------

void GameObjectManager::UpdateAllObjects(DWORD Milliseconds)
{
	bool ReturnValue;
	static bool SpawnNewBoss = false;

	std::vector<GameObject*>::iterator it;
	for (it = GameObjectList.begin(); it != GameObjectList.end();)
	{
		ReturnValue=(*it)->Update(Milliseconds);
		if (ReturnValue == false)
		{
			delete (*it);
			it = GameObjectList.erase(it);	
			SpawnNewBoss = true;
			//Remember to add delay
			
		}
		else
		{
			++it;
		}
	}

	if (SpawnNewBoss == true && BPool->ActiveBullets.empty() && VioletBPool->ActiveBullets.empty())
	{
		SpawnNewBoss = false;
		SpawnNextBoss();
	}

	for (it = BPool->ActiveBullets.begin(); it != BPool->ActiveBullets.end();)
	{
		ReturnValue = (*it)->Update(Milliseconds);
		if (ReturnValue == false)
		{
			it=BPool->RemoveBullet(it);
		
		}
		else
		{
			++it;
		}
	}

	for (it = VioletBPool->ActiveBullets.begin(); it != VioletBPool->ActiveBullets.end();)
	{
		ReturnValue = (*it)->Update(Milliseconds);
		if (ReturnValue == false)
		{
			it = VioletBPool->RemoveBullet(it);

		}
		else
		{
			++it;
		}
	}

	for (it = PlayerBPool->ActiveBullets.begin(); it != PlayerBPool->ActiveBullets.end();)
	{
		ReturnValue = (*it)->Update(Milliseconds);
		if (ReturnValue == false)
		{
			it = PlayerBPool->RemoveBullet(it);

		}
		else
		{
			++it;
		}
	}

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: AddGameObjects(GameObject*)
//		 Inputs: A pointer to the object that needs to be added to the list
//	    Outputs: Adds the objects to the vector contatining the list of all non bullet objects in the scene
//	Description: Adds object to the vector containing the list of all non bullet objects in the scene
//				
//----------------------------------------------------------------------------------------------------------------------
void GameObjectManager::AddGameObject(GameObject* NewObject)
{
	GameObjectList.push_back(NewObject);
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: RemoveGameObject(GameObject*)
//		 Inputs: Pointer to the object being deleted
//	    Outputs: The object is deleted and can be removed from the vector containing all objects in the scene
//	Description: Deletes the referenced object
//				
//----------------------------------------------------------------------------------------------------------------------
void GameObjectManager::RemoveGameObject(GameObject* ObjectToRemove)
{
	delete ObjectToRemove;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Initialize()
//		 Inputs: N/A
//	    Outputs: Initializes the core things needed to start the game
//	Description: Instances Player, Creates the bullet pools, Instances the first boss, Preloads all textures in the game
//				
//----------------------------------------------------------------------------------------------------------------------

void GameObjectManager::Initialize()
{
	GameObject *PlayerObject = new Player();
	GameObjectManager::GetInstance()->AddGameObject(PlayerObject);
	PlayerIndex = GameObjectList.size() - 1;
	CurrentBulletTexturesIndex = -1;
	CurrentBossTextureIndex = 0;

	std::vector<std::string> TexturePaths = CGame::GetInstance()->ReturnTexturePaths();
	GLuint temp;
	for (std::vector<std::string>::iterator it = TexturePaths.begin(); it != TexturePaths.end(); it++)
	{

		temp = SOIL_load_OGL_texture((*it).c_str(), SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID,
			SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);

		BossTextures.push_back(temp);

	}

	SpawnNextBoss();

	GameObjectManager::GetInstance()->BPool = new BulletPool();
	GameObjectManager::GetInstance()->BPool->Initialize(BulletPoolSize);

	GameObjectManager::GetInstance()->VioletBPool = new BulletPool();
	GameObjectManager::GetInstance()->VioletBPool->Initialize(BulletPoolSize);

	GameObjectManager::GetInstance()->PlayerBPool = new BulletPool();
	GameObjectManager::GetInstance()->PlayerBPool->Initialize(PlayerBulletPoolSize);

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: ReturnBulletPool()
//		 Inputs: N/A
//	    Outputs: Returns an instance to the BulletPool
//	Description: ^
//				
//----------------------------------------------------------------------------------------------------------------------

BulletPool* GameObjectManager::ReturnBulletPool()
{
	return BPool;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: AddBullet(float PositionX, float PositionY, float Velocity, int PID, int BulletTextureIndex, float InitialAngle)
//		 Inputs: Variables required to spawn a bullet
//	    Outputs: Calls the appropriate bullet pool to initialize a new bullet, The bullet pool used is based on the texture. This is done so they can be sprite batched in the draw function
//	Description: Spawns a bullet from the appropriate bullet pool, this function is for bosses only
//				
//----------------------------------------------------------------------------------------------------------------------
void GameObjectManager::AddBullet(float PositionX, float PositionY, float Velocity, int PID, int BulletTextureIndex, float InitialAngle)
{
	if (BulletTextureIndex == 1)
	{
		BPool->GetBullet(PositionX, PositionY, Velocity, PID, CurrentBulletTexturesIndex, InitialAngle);
	}
	else
	{
		VioletBPool->GetBullet(PositionX, PositionY, Velocity, PID, CurrentBulletTexturesIndex + 1, InitialAngle);
	}
}


//---------------------------------------------------------------------------------------------------------------------
//Function Name: GetBullet(float PositionX, float PositionY, float Velocity, int PID, int BulletTextureIndex, float InitialAngle)
//		 Inputs: Variables required to spawn a bullet
//	    Outputs: Calls the appropriate bullet pool to initialize a new bullet, The bullet pool used is based on the texture. This is done so they can be sprite batched in the draw function
//	Description: Spawns a bullet from the appropriate bullet pool, this function is for the player bullets only
//				
//----------------------------------------------------------------------------------------------------------------------

void GameObjectManager::AddPlayerBullet(float PositionX, float PositionY, float Velocity, int PID, int BulletTextureIndex, float InitialAngle)
{
	PlayerBPool->GetBullet(PositionX, PositionY, Velocity, PID, BulletTextureIndex, InitialAngle);
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: PerformCollisions()
//		 Inputs: N/A
//	    Outputs: Checks between the player bullets and the boss, likewise checks for collision between the player and the bosses bullets
//	Description: Uses Distance Square checking for collisions, performs the appropriate functionality (Health/Score Reduction) on collision.
//				
//----------------------------------------------------------------------------------------------------------------------

void GameObjectManager::PerformCollisions()
{
	std::vector<GameObject*>::iterator it;
	float temp;

	if (PlayerBPool->ActiveBullets.size() > 0 && GameObjectList.size() > BossIndex)
	{
		for (it = PlayerBPool->ActiveBullets.begin(); it != PlayerBPool->ActiveBullets.end();)
		{
			temp = (*it)->GetPosition().y - ((*it)->GetHeight()) / 2;
			if (temp > GameObjectList[BossIndex]->GetPosition().y)
			{
				temp= (*it)->GetPosition().x - ((*it)->GetWidth()) / 2;
				if (temp > (GameObjectList[BossIndex]->GetPosition().x - (GameObjectList[BossIndex]->GetWidth() / 2)) && temp < (GameObjectList[BossIndex]->GetPosition().x + (GameObjectList[BossIndex]->GetWidth() / 2)))
				{
					it = PlayerBPool->RemoveBullet(it);
					dynamic_cast<Boss*>(GameObjectList[BossIndex])->TakeDamage();
					CGame::GetInstance()->AddScore(5);
					
				}
				else
				{
					++it;
				}
			}
			else
			{
				++it;
			}
		}
	}



	if (BPool->ActiveBullets.size() > 0)
	{
		Coord2D PlayerPosition = GameObjectList[PlayerIndex]->GetPosition();
		Coord2D BulletPosition;

		for (it = BPool->ActiveBullets.begin(); it != BPool->ActiveBullets.end();)
		{
			BulletPosition = (*it)->GetPosition();

			temp = pow((PlayerPosition.x - BulletPosition.x), 2) + pow((PlayerPosition.y - BulletPosition.y), 2);

			if (temp <= 10000)
			{
				int PlayerHealth,BossHealth;

				it = BPool->RemoveBullet(it);
				if (CGame::GetInstance()->EndGameReached() == false)
				{
					CGame::GetInstance()->AddScore(-2);
				}
				PlayerHealth = dynamic_cast<Player*>(GameObjectList[PlayerIndex])->ReduceHealth(2);
				AudioManagerC::GetInstance()->PlaySounds(SoundIndex::PlayerCollision);
				if (PlayerHealth < 1)
				{
					if (CGame::GetInstance()->EndGameReached() == false)
					{
						dynamic_cast<Player*>(GameObjectList[PlayerIndex])->ResetHealth();
						if (GameObjectList.size() > BossIndex)
						{
							BossHealth = dynamic_cast<Boss*>(GameObjectList[BossIndex])->ResetHealth();
							CGame::GetInstance()->AddScore(-(BossHealth * 2));
						}
					}
				}
			}
			else
			{
				++it;
			}
		}

	}

	if (VioletBPool->ActiveBullets.size() > 0)
	{
		Coord2D PlayerPosition = GameObjectList[PlayerIndex]->GetPosition();
		Coord2D BulletPosition;

		for (it = VioletBPool->ActiveBullets.begin(); it != VioletBPool->ActiveBullets.end();)
		{
			BulletPosition = (*it)->GetPosition();

			temp = pow((PlayerPosition.x - BulletPosition.x), 2) + pow((PlayerPosition.y - BulletPosition.y), 2);

			if (temp <= 4900)
			{
				int PlayerHealth, BossHealth;
				it = VioletBPool->RemoveBullet(it);
				if (CGame::GetInstance()->EndGameReached() == false)
				{
					CGame::GetInstance()->AddScore(-2);
				}
				PlayerHealth = dynamic_cast<Player*>(GameObjectList[PlayerIndex])->ReduceHealth(2);
				AudioManagerC::GetInstance()->PlaySounds(SoundIndex::PlayerCollision);
				if (PlayerHealth < 1)
				{
					if (CGame::GetInstance()->EndGameReached() == false)
					{
						dynamic_cast<Player*>(GameObjectList[PlayerIndex])->ResetHealth();
						if (GameObjectList.size() > BossIndex)
						{
							BossHealth = dynamic_cast<Boss*>(GameObjectList[BossIndex])->ResetHealth();
							CGame::GetInstance()->AddScore(-(BossHealth * 2));
						}
					}
					else
					{
						CGame::GetInstance()->EndGameScreen();
					}
				}
			}
			else
			{
				++it;
			}
		}

	}

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: SpawnNextBoss()
//		 Inputs: N/A
//	    Outputs: Spawns the next boss in sequence
//	Description: ^
//				
//----------------------------------------------------------------------------------------------------------------------

void GameObjectManager::SpawnNextBoss()
{
	BossSpawnData Temp;


	Temp=CGame::GetInstance()->GetBossData();
	if (CGame::GetInstance()->EndGameReached() == false)
	{
		GameObject *NextBoss = new Boss(Temp.VelocityMagnitude, Temp.TextureFilePath, Temp.Position.x, Temp.Position.y, Temp.Height, Temp.Width, Temp.Health, Temp.FireRate, Temp.BossID, Temp.SpawnOffsets, BossTextures[CurrentBossTextureIndex]);
		GameObjectManager::GetInstance()->AddGameObject(NextBoss);
		BossIndex = GameObjectList.size() - 1;
		CGame::GetInstance()->ActivateTransitionMode();
		CurrentBulletTexturesIndex += 2;
		CurrentBossTextureIndex++;
		dynamic_cast<Player*>(GameObjectList[PlayerIndex])->ResetHealth();
	}
	else
	{
		CGame::GetInstance()->InitiateCreditsMode();
	}
}


//---------------------------------------------------------------------------------------------------------------------
//Function Name: ReturnPlayerPosition()
//		 Inputs: N/A
//	    Outputs: Returns the position of the Player in the game
//	Description: ^
//				
//----------------------------------------------------------------------------------------------------------------------

Coord2D GameObjectManager::ReturnPlayerPosition()
{
	return GameObjectList[PlayerIndex]->GetPosition();
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: DrawOnlyPlayerObject()
//		 Inputs: N/A
//	    Outputs: Draws only the player objects, used for the hyper space transition
//	Description: ^
//				
//----------------------------------------------------------------------------------------------------------------------

void GameObjectManager::DrawOnlyPlayerObject()
{
	GameObjectList[PlayerIndex]->Draw();
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: UpdateOnlyPlayer(DWORD)
//		 Inputs: Delta Time
//	    Outputs: Updates only the player, used for hyper space transition
//	Description: 
//				
//----------------------------------------------------------------------------------------------------------------------

void GameObjectManager::UpdateOnlyPlayer(DWORD Milliseconds)
{
	GameObjectList[PlayerIndex]->Update(Milliseconds);
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: EmptyPlayerBullets()
//		 Inputs: N/A
//	    Outputs: Removes all player bullets from the field and puts them into the inactive pool
//	Description: ^
//				
//----------------------------------------------------------------------------------------------------------------------

void GameObjectManager::EmptyPlayerBullets()
{
	std::vector<GameObject*>::iterator it;
	for (it = PlayerBPool->ActiveBullets.begin(); it != PlayerBPool->ActiveBullets.end();)
	{
		it = PlayerBPool->RemoveBullet(it);
	}
}


//---------------------------------------------------------------------------------------------------------------------
//Function Name: SpawnFinalBoss()
//		 Inputs: N/A
//	    Outputs: Spawns the post credit boss
//	Description: ^
//				
//----------------------------------------------------------------------------------------------------------------------
void GameObjectManager::SpawnFinalBoss()
{
	BossSpawnData Temp;
	Temp = CGame::GetInstance()->GetBossData();
	GameObject *NextBoss = new Boss(Temp.VelocityMagnitude, Temp.TextureFilePath, Temp.Position.x, Temp.Position.y, Temp.Height, Temp.Width, Temp.Health, Temp.FireRate, Temp.BossID, Temp.SpawnOffsets,BossTextures[CurrentBossTextureIndex]);
	GameObjectManager::GetInstance()->AddGameObject(NextBoss);
	BossIndex = GameObjectList.size() - 1;
	CurrentBulletTexturesIndex += 2;
	CurrentBossTextureIndex++;
	CGame::GetInstance()->ActivateTransitionMode();

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: ResetObjects()
//		 Inputs: N/A
//	    Outputs: Resets all objects to the iniital state
//	Description: Used to restart the game
//				
//----------------------------------------------------------------------------------------------------------------------

void GameObjectManager::ResetObjects()
{
	RemoveGameObject(GameObjectList[BossIndex]);
	GameObjectList.erase(GameObjectList.begin()+BossIndex);
	EmptyPlayerBullets();
	CurrentBulletTexturesIndex = -1;
	CurrentBossTextureIndex = 0;
	std::vector<GameObject*>::iterator it;
	for (it = BPool->ActiveBullets.begin(); it != BPool->ActiveBullets.end();)
	{
		it = BPool->RemoveBullet(it);
	}
	for (it = VioletBPool->ActiveBullets.begin(); it != VioletBPool->ActiveBullets.end();)
	{
		it = VioletBPool->RemoveBullet(it);
	}
	SpawnNextBoss();
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Shutdown()
//		 Inputs: N/A
//	    Outputs: Deinitializes all variables
//	Description: 
//				
//----------------------------------------------------------------------------------------------------------------------
void GameObjectManager::Shutdown()
{
	for (std::vector<GameObject*>::iterator it = GameObjectList.begin(); it != GameObjectList.end();)
	{
		RemoveGameObject(*it);
		it = GameObjectList.erase(it);
	}

	BPool->ShutDown();
	VioletBPool->ShutDown();
	PlayerBPool->ShutDown();
}