#include "Audio.h"
#include "fmod.hpp"
#include "fmod_errors.h"

Audio::Audio()
{
	if (FMOD::System_Create(&mSystem) != FMOD_OK)
	{
		return;
	}
	// Check if the PC has a sound driver
	int driverCount = 0;
	mSystem->getNumDrivers(&driverCount);
	if (driverCount == 0)
	{
		return;
	}
	// Initialize an instance with 12 channels
	mSystem->init(12, FMOD_INIT_NORMAL, nullptr);
};

//gets the sound location and creates a audio que ready to be played
Sound* Audio::createSound(const char* pFile)
{
	Sound *pSound = new Sound();
	mSystem->createSound(pFile, FMOD_DEFAULT, 0, pSound);
	return pSound;
}

//check for looping info in audio and proceed  to place audio in one of the channels and play
void Audio::playSound(Sound &pSound, bool loop)
{
	if (!loop)
	{
		pSound->setMode(FMOD_LOOP_OFF);
	}
	else
	{
		pSound->setMode(FMOD_LOOP_NORMAL);
		pSound->setLoopCount(-1);
	}

	mSystem->playSound(pSound, 0, false, 0);
}

//release loaded audio
void Audio::releaseSound(Sound &pSound)
{
	pSound->release();
}