#pragma once
#include "GameObject.h"



GameObject::GameObject()
{
}


GameObject::~GameObject()
{
}

void GameObject::Draw()
{
	
}

bool GameObject::Update(DWORD Milliseconds)
{
	return true;
}

void GameObject::Render(GLuint TextureHandle)
{
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, GlTextureHandle);
	glBegin(GL_QUADS);

	GLfloat XPositionLeft = Position.x - (Width / 2);
	GLfloat XPositionRight = Position.x + (Width / 2);
	GLfloat YPositionTop = Position.y + (Height / 2);
	GLfloat YPositionBottom = Position.y - (Height / 2);

	/*GLfloat XTextureCoord = 1;
	GLfloat YTextureCoord = 1;*/

	glColor4ub(0xFF, 0xFF, 0xFF, 0xFF);


	//Bottom Left Vertex
	glTexCoord2f(0, 0);
	glVertex3f(XPositionLeft, YPositionBottom, 0);

	//Bottom Right Vertex
	glTexCoord2f(1, 0);
	glVertex3f(XPositionRight, YPositionBottom, 0);

	//Top Right Vertex
	glTexCoord2f(1, 1);
	glVertex3f(XPositionRight, YPositionTop, 0);

	//Top Left Vertex
	glTexCoord2f(0, 1);
	glVertex3f(XPositionLeft, YPositionTop, 0);





	glEnd();
}

void GameObject::Initialize(float PositionX, float PositionY, float Velocity, int PID, GLuint TextureHandle, float InitialAngle)
{

}

GLuint GameObject::GetTextureHandle()
{
	return GlTextureHandle;
}

Coord2D GameObject::GetPosition()
{
	return Position;
}

float GameObject::GetWidth()
{
	return Width;
}

float GameObject::GetHeight()
{
	return Height;
}