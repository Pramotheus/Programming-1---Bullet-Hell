#pragma once
#include<Windows.h>
#include "MainMenu.h"
#include"game.h"
#include"glut.h"
#include"gl\gl.h"
#include"InputManager.h"


MainMenu* MainMenu::Instance = nullptr;

//---------------------------------------------------------------------------------------------------------------------
//Function Name: MainMenu()
//		 Inputs: N/A
//	    Outputs: Initializes text to be drawn on the screen
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

MainMenu::MainMenu()
{
	MainMenuText.push_back("Programming 1");
	MainMenuText.push_back("Bullet Hell");
	MainMenuText.push_back("Press A to Start");
	MainMenuText.push_back("Controls:");
	MainMenuText.push_back("Left Stick to Move, A or RT to Fire");
	MainMenuText.push_back("This game is a work of fiction and any resemblance to any real people is purely coincidental");

}


MainMenu::~MainMenu()
{
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Draw()
//		 Inputs: N/A
//	    Outputs: Draws the main menu to the screen
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void MainMenu::Draw()
{
	glDisable(GL_TEXTURE_2D);
	glColor3f(1.0f, 1.0f, 1.0f);
	
	glRasterPos2i(-250, 200);

	for (int i = 0; i < MainMenuText[0].length(); i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (MainMenuText[0])[i]);
	}

	glRasterPos2i(-200, 0);

	for (int i = 0; i < MainMenuText[1].length(); i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, (MainMenuText[1])[i]);
	}

	glRasterPos2i(-250, -200);

	for (int i = 0; i < MainMenuText[2].length(); i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (MainMenuText[2])[i]);
	}


	glRasterPos2i(-200, -1000);

	for (int i = 0; i < MainMenuText[3].length(); i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, (MainMenuText[3])[i]);
	}

	glRasterPos2i(-400, -1100);

	for (int i = 0; i < MainMenuText[4].length(); i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, (MainMenuText[4])[i]);
	}



}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Update()
//		 Inputs: N/A
//	    Outputs: Checks for input in the menu
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void  MainMenu::Update()
{
	int Result;
	Result = InputManagerC::GetInstance()->IsPlayerFireActive();

	if (Result != 0)
	{
		CGame::GetInstance()->StartGame();
	}

}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: CreateInstance()
//		 Inputs: N/A
//	    Outputs: Creates an instance of the class
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

MainMenu* MainMenu::CreateInstance()
{
	Instance = new MainMenu();
	return Instance;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: GetInstance()
//		 Inputs: N/A
//	    Outputs: Returns Instance
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

MainMenu* MainMenu::GetInstance()
{
	return Instance;
}