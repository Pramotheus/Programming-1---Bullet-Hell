#pragma once
#include "Player.h"
#include "GameObjectManager.h"
#include"InputManager.h"
#include"game.h"
#include "AudioManagerC.h"
#include<iostream>
#include "Text.h"

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Player()
//		 Inputs: N/A
//	    Outputs: Initializes player with required variable
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------
Player::Player()
{
	VelocityMagnitude = 20;
	Velocity.x = (float)VelocityMagnitude*(float)std::cos(45 * (3.1415 / 180));
	Velocity.y = (float)VelocityMagnitude*(float)std::sin(45 * (3.1415 / 180));
	TextureFilePath = "Sprites/PlayerIcon.png";
	Position.x = 0;
	Position.y = -1000;
	Height = 128;
	Width = 128;
	Health = 20;

	GlTextureHandle = SOIL_load_OGL_texture(TextureFilePath.c_str(), SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID,
		SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);

	Score = 0;
	IsInvinicible = false;
	FireRate = 0.2f;
}


Player::~Player()
{
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Update(DWORD)
//		 Inputs:Delta Time
//	    Outputs: Updates position of the player within the bounds of the screen, also checks if the player is firing or has pressed restart
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

bool Player::Update(DWORD Milliseconds)
{
	if (InputManagerC::GetInstance()->IsQuitPressed() == true)
	{
		CGame::GetInstance()->RestartGame();
	}

	static float NextFire = 0;

	int DirectionX = 0, DirectionY = 0;

	DirectionX = InputManagerC::GetInstance()->GetLeftRightMovement();
	DirectionY = InputManagerC::GetInstance()->GetForwardBackMovement();

	if (DirectionX != 0 && DirectionY != 0)
	{
		Position.x += GetLinearXVelocity() *(Milliseconds / 10)*DirectionX;

		Position.y += GetLinearYVelocity() *(Milliseconds / 10)*DirectionY;

	}
	else
	{
		Position.x += VelocityMagnitude *(Milliseconds / 10)*DirectionX;

		Position.y += VelocityMagnitude *(Milliseconds / 10)*DirectionY;
	}

	if ((Position.x > 1950) || (Position.x < -1950))
	{
		Position.x = std::copysign(1950, Position.x);
	}

	if (Position.y > 1950 || Position.y < -1950)
	{
		Position.y = std::copysign(1950,Position.y);
	}

	if ((InputManagerC::GetInstance()->IsPlayerFireActive()) && (NextFire < CGame::GetInstance()->GetElapsedTime()))
	{
		AudioManagerC::GetInstance()->PlaySounds(SoundIndex::PlayerLaser);
		GameObjectManager::GetInstance()->AddPlayerBullet(Position.x, Position.y, 25, 0, 0, 0);				
		NextFire = CGame::GetInstance()->GetElapsedTime() + FireRate;
	}

	return true;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: Draw()
//		 Inputs: N/A
//	    Outputs: Renders the Player on the screen along with his health bar
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void Player::Draw()
{
	Render(GlTextureHandle);
	UI::GetInstance()->displayPlayerHealth(Health, Position.x, Position.y);
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: GetLinearXVelocity()
//		 Inputs: N/A
//	    Outputs: Get X component of velocity
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

float Player::GetLinearXVelocity()
{
	return (float)VelocityMagnitude*(float)std::cos(45 * (3.1415 / 180));
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: GetLinearYVelocity()
//		 Inputs: N/A
//	    Outputs: Get Y Component of velocity
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

float Player::GetLinearYVelocity()
{
	return (float)VelocityMagnitude*(float)std::sin(45 * (3.1415 / 180));
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: ReduceHealth
//		 Inputs: Amount of health to be reduced
//	    Outputs: Reduced health
//	Description: Reduces health of player and returns the health.
//				 
//----------------------------------------------------------------------------------------------------------------------

int Player::ReduceHealth(int Amount)
{
	if (CGame::GetInstance()->EndGameReached() == false)
	{
		Health -= Amount;
	}
	else
	{
		Health = Health - 1;
		if (Health < 0)
		{
			Health = 0;
		}
	}
	return Health;
}

//---------------------------------------------------------------------------------------------------------------------
//Function Name: ResetHealth()
//		 Inputs: N/A
//	    Outputs: Resets player health back to 20
//	Description: 
//				 
//----------------------------------------------------------------------------------------------------------------------

void Player::ResetHealth()
{
	Health = 20;
}

void Player::Initialize(float PositionX, float PositionY, float Velocity, int PID, GLuint TextureHandle, float InitialAngle)
{

}

